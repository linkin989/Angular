package com.mvc.task;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Login {
	@RequestMapping("/validate")
	public ModelAndView validate(@RequestParam("uname") String name ,@RequestParam String pass){
		
		System.out.println(name + " " + pass);
		String result;
		ModelAndView mv=new ModelAndView();
		if(name.equals(pass))
		{
			result="Success";
			mv.setViewName("success.jsp");
			mv.addObject(result);
		}
		
	else
		result="failure";
	  mv.setViewName("error.jsp");
	  mv.addObject(result);
	  return mv;
		
	}
	

}
