package com.cap.EducationalDetails;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cap.PageBean.EducationalPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	
	private WebDriver driver;
	
	private EducationalPage edu;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\nifasa\\Desktop\\chromedriver.exe");

		driver = new ChromeDriver();
	}
	
	
	@Given("^the user is on Educational Details page$")
	public void the_user_is_on_Educational_Details_page() throws Throwable {
		driver.get("C:\\Users\\nifasa\\Desktop\\link\\EducationalDetails.html");

		edu= new EducationalPage(driver);
		
		
	}

	@Then("^Checks if the title of the page is 'Educational Details'$")
	public void checks_if_the_title_of_the_page_is_Educational_Details() throws Throwable {
	   
		String title = driver.getTitle();
		
		Assert.assertEquals("EducationalDetails", title);

		
		
	}

	@Then("^Check if there is a text 'Step (\\d+): Educational Details'$")
	public void check_if_there_is_a_text_Step_Educational_Details(int arg1) throws Throwable {
	    
		
		
		
		
	}

	@When("^user does'nt select Graduation$")
	public void user_does_nt_select_Graduation() throws Throwable {
	   
		
		
		
	}

	@Then("^display 'Please Select Graduation'$")
	public void display_Please_Select_Graduation() throws Throwable {
	   
		
		
		
	}

	@When("^user does'nt enter percentag$")
	public void user_does_nt_enter_percentag() throws Throwable {
	   
		
		
		
	}

	@Then("^display 'Please fill Percentage detail'$")
	public void display_Please_fill_Percentage_detail() throws Throwable {
	   
		
		
		
	}

	@When("^user does'nt enter Passing Year$")
	public void user_does_nt_enter_Passing_Year() throws Throwable {
	  
		
		
		
	}

	@Then("^display 'Please fill Passing Year '$")
	public void display_Please_fill_Passing_Year() throws Throwable {
	   
		
		
		
	}

	@When("^user does'nt enter Project Name$")
	public void user_does_nt_enter_Project_Name() throws Throwable {
	   
		
		
		
	}

	@Then("^display 'Please fill Project Name'$")
	public void display_Please_fill_Project_Name() throws Throwable {
	   
		
		
	}

	@When("^user does'nt select Technologies$")
	public void user_does_nt_select_Technologies() throws Throwable {
	    
		
		
		
	}

	@Then("^display 'Please Select Technologies Used'$")
	public void display_Please_Select_Technologies_Used() throws Throwable {
	   
		
		
	}

	@When("^user does'nt enter Other Technologies$")
	public void user_does_nt_enter_Other_Technologies() throws Throwable {
	    
		
		
	}

	@Then("^display 'Please fill other Technologies Used '$")
	public void display_Please_fill_other_Technologies_Used() throws Throwable {
	   
		
		
	}

	@When("^user enters all information$")
	public void user_enters_all_information() throws Throwable {
	  
		
		
	}

	@Then("^display 'Your Registration Has succesfully done Plz check you registerd email for account activation link !!!'$")
	public void display_Your_Registration_Has_succesfully_done_Plz_check_you_registerd_email_for_account_activation_link() throws Throwable {
	   
		
		
		
	}
	
	


}
