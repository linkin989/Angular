package com.cap.PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PersonalPage {
	
	WebDriver driver;
	
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	@FindBy(id = "txtFirstName")
	@CacheLookup
	WebElement firstName;
	
	

	@FindBy( id="txtLastName")
	@CacheLookup
	WebElement lastName;
	
	
	
	@FindBy( id="txtEmail")
	@CacheLookup
	WebElement email;
	
	
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement mobileno;
	
	
	

	@FindBy(id="txtAddress1")
	@CacheLookup
	WebElement Line1;
	
	
	
	@FindBy(id="txtAddress2")
	@CacheLookup
	WebElement Line2;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement state;
	
	@FindBy(linkText="Next")
	@CacheLookup
	WebElement nextLink;

	
	

	public WebElement getNextLink() {
		return nextLink;
	}

	public void setNextLink() {
		this.nextLink.click();
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName( String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno.sendKeys(mobileno);
	}

	public WebElement getLine1() {
		return Line1;
	}

	public void setLine1(String line1) {
		Line1.sendKeys(line1);
	}

	public WebElement getLine2() {
		return Line2;
	}

	public void setLine2(String line2) {
		Line2.sendKeys(line2);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public PersonalPage(WebDriver driver) {
	
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	

}
