package com.cap.PersonalDetail;



import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cap.PageBean.PersonalPage;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {

	private WebDriver driver;

	private PersonalPage personal;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\nifasa\\Desktop\\chromedriver.exe");

		driver = new ChromeDriver();
	}
	


	@Given("^user is on 'PersonalDetails' page$")
	public void user_is_on_PersonalDetails_page() throws Throwable {
		driver.get("C:\\Users\\nifasa\\Desktop\\link\\PersonalDetails.html");
		
				personal = new PersonalPage(driver);
	}

	@Then("^Checks if the title of the page is 'PersonalDetails'$")
	public void checks_if_the_title_of_the_page_is_PersonalDetails() throws Throwable {
		String title = driver.getTitle();
	
			Assert.assertEquals("Personal Details", title);
	}

	@Then("^Check if there is a text 'Step (\\d+): PersonalDetails'$")
	public void check_if_there_is_a_text_Step_PersonalDetails(int arg1) throws Throwable {
		String heading = driver.findElement(By.xpath("//h4[@style='font-family:Calibri;']")).getText();
	
		Assert.assertEquals("Step 1: Personal Details", heading);
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
		personal.setFirstName("");
		personal.setNextLink();
	}

	@Then("^displays 'Please fill the first Name'$")
	public void displays_Please_fill_the_first_Name() throws Throwable {
		String expectedMessage = "Please fill the First Name";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
	    driver.switchTo().alert().accept();
		driver.close();

	}

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
		personal.setFirstName("Yogini");
		personal.setLastName("");
    	personal.setNextLink();
	}

	@Then("^displays 'Please fill the Last Name'$")
	public void displays_Please_fill_the_Last_Name() throws Throwable {
		String expectedMessage = "Please fill the Last Name";
		String actualMessage = driver.switchTo().alert().getText();
	Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		personal.setFirstName("nifas");
		personal.setLastName("khan");
		personal.setEmail("nifas");
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
		String expectedMessage = "Please fill the Email";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
		personal.setFirstName("Yogini");
	personal.setLastName("Naik");
		personal.setEmail("yogini@gmail.com");
	personal.setMobileno("");
	personal.setNextLink();
	}

	@Then("^display 'Please fill Mobile No\\.'$")
	public void display_Please_fill_Mobile_No() throws Throwable {
		String expectedMessage = "Please fill the Mobile No.";
		String actualMessage = driver.switchTo().alert().getText();
   Assert.assertEquals(expectedMessage, actualMessage);
	driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user does not enter address$")
	public void user_does_not_enter_address() throws Throwable {
		personal.setFirstName("nifas");
		personal.setLastName("khan");
		personal.setEmail("yogini@gmail.com");
		personal.setMobileno("");
		personal.setLine1("");
		personal.setLine2("");
		personal.setNextLink();
	}

	@Then("^display 'Please Enter Address'$")
	public void display_Please_Enter_Address() throws Throwable {
		personal.setFirstName("nifas");
		personal.setLastName("khan");
		personal.setEmail("nifas@gmail.com");
		personal.setMobileno("");
		personal.setLine1("rg colony");
		personal.setLine2("gr colony");
		personal.setNextLink();
	}

	@When("^user enters invalid City$")
	public void user_enters_invalid_City() throws Throwable {
		personal.setFirstName("nifas");
		personal.setLastName("khan");
		personal.setEmail("nifas@gmail.com");
		personal.setMobileno("9674563214");
		personal.setCity("Select City");
		personal.setNextLink();
	}

	@Then("^display 'Please fill City'$")
	public void display_Please_fill_City() throws Throwable {
		String expectedMessage = "Please select city";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid State$")
	public void user_enters_invalid_State() throws Throwable {
		personal.setFirstName("Nifas");
		personal.setLastName("khan");
		personal.setEmail("nifas@gmail.com");
		personal.setMobileno("8745632145");
		personal.setCity("pune");
		personal.setState("Select State");
		personal.setNextLink();
	}

	@Then("^display 'Please fill the State'$")
	public void display_Please_fill_the_State() throws Throwable {
		String expectedMessage = "Please select state";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}
	
	@When("^user clicks the Next link$")
	public void user_clicks_the_Next_link() throws Throwable {
		personal.setFirstName("Nifas");
		personal.setLastName("khan");
		personal.setEmail("nifas@gmail.com");
		personal.setMobileno("8745632145");
		personal.setCity("pune");
		personal.setState("Tamilnadu");
		personal.setNextLink();
	}
	
	@Then("^it displays 'Personal details are validated and accepted successfully\\.'$")
	public void it_displays_Personal_details_are_validated_and_accepted_successfully() throws Throwable {
		String expectedMessage = "Personal details are validated and accepted successfully.";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@Then("^verify it is on 'EducationalDetails' page$")
	public void verify_it_is_on_EducationalDetails_page() throws Throwable {
		driver.get("C:\\Users\\nifasa\\Desktop\\link\\EducationalDetails.html");
	}
	



	}

