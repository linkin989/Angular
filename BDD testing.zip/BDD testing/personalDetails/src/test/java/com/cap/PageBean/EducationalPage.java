package com.cap.PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

public class EducationalPage {
	
	WebDriver driver;
	
	
	
	@FindBy(name="graduation")
	@CacheLookup
	WebElement graduation;
	
	
	
	@FindBy( id="txtPercentage")
	@CacheLookup
	WebElement percentage;
	
	
	@FindBy( id="txtPassYear")
	@CacheLookup
	WebElement passyear;
	
	@FindBy( id="txtProjectName" )
	@CacheLookup
	WebElement projectname;
	
	
	@FindBy( xpath="//input[@value='other']" )
	@CacheLookup
	WebElement technology;
	
	@FindBy( id="btnRegister" )
	@CacheLookup
	WebElement registerBtn;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getGraduation() {
		return graduation;
	}

	public void setGraduation(String graduation) {
		this.graduation.sendKeys(graduation);
	}

	public WebElement getPercentage() {
		return percentage;
	}

	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}

	public WebElement getPassyear() {
		return passyear;
	}

	public void setPassyear(String passyear) {
		this.passyear.sendKeys(passyear);
	}

	public WebElement getProjectname() {
		return projectname;
	}

	public void setProjectname(String projectname) {
		this.projectname.sendKeys(projectname);
	}

	public WebElement getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology.sendKeys( technology);
	}

	public WebElement getRegisterBtn() {
		return registerBtn;
	}

	public void setRegisterBtn() {
		this.registerBtn.click();
	}

	public EducationalPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	
	
	
	
	
	
	

}
