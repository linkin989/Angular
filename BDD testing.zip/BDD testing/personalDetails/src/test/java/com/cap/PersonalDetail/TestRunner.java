package com.cap.PersonalDetail;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		
		features= {"C:\\Users\\nifasa\\Desktop\\Testing1\\personalDetails\\src\\test\\resource\\Features\\Personal.feature"},
		 glue= {"com.cap.PersonalDetail"},

		  dryRun=false,
		  strict=true,
		  monochrome=true,
		 format = {"pretty" , "html:test-output"}
		)


public class TestRunner {

}
