$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/nifasa/Desktop/Testing1/personalDetails/src/test/resource/Features/Personal.feature");
formatter.feature({
  "line": 1,
  "name": "personaldetails",
  "description": "",
  "id": "personaldetails",
  "keyword": "Feature"
});
formatter.before({
  "duration": 9018877700,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "check Title and Text on page",
  "description": "",
  "id": "personaldetails;check-title-and-text-on-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "user is on \u0027PersonalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "Checks if the title of the page is \u0027PersonalDetails\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "Check if there is a text \u0027Step 1: PersonalDetails\u0027",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefinition.user_is_on_PersonalDetails_page()"
});
formatter.result({
  "duration": 1872335700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.checks_if_the_title_of_the_page_is_PersonalDetails()"
});
formatter.result({
  "duration": 28652500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 31
    }
  ],
  "location": "StepDefinition.check_if_there_is_a_text_Step_PersonalDetails(int)"
});
formatter.result({
  "duration": 64124500,
  "status": "passed"
});
formatter.before({
  "duration": 3792501900,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Invalid firstname",
  "description": "",
  "id": "personaldetails;invalid-firstname",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user is on \u0027PersonalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "user enters invalid first name",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "displays \u0027Please fill the first Name\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_PersonalDetails_page()"
});
formatter.result({
  "duration": 5402836700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_invalid_first_name()"
});
formatter.result({
  "duration": 174935100,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.displays_Please_fill_the_first_Name()"
});
formatter.result({
  "duration": 807202100,
  "status": "passed"
});
formatter.before({
  "duration": 1810445600,
  "status": "passed"
});
formatter.scenario({
  "line": 19,
  "name": "Invalid lastname",
  "description": "",
  "id": "personaldetails;invalid-lastname",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 20,
  "name": "user is on \u0027PersonalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 21,
  "name": "user enters invalid last name",
  "keyword": "When "
});
formatter.step({
  "line": 22,
  "name": "displays \u0027Please fill the Last Name\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_PersonalDetails_page()"
});
formatter.result({
  "duration": 4221667200,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_invalid_last_name()"
});
formatter.result({
  "duration": 268597000,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.displays_Please_fill_the_Last_Name()"
});
formatter.result({
  "duration": 182219700,
  "status": "passed"
});
formatter.before({
  "duration": 2246409100,
  "status": "passed"
});
formatter.scenario({
  "line": 24,
  "name": "Invalid email",
  "description": "",
  "id": "personaldetails;invalid-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 25,
  "name": "user is on \u0027PersonalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 26,
  "name": "user enters invalid email",
  "keyword": "When "
});
formatter.step({
  "line": 27,
  "name": "display \u0027Please fill the Email\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_PersonalDetails_page()"
});
formatter.result({
  "duration": 4082730700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_invalid_email()"
});
formatter.result({
  "duration": 295763900,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.display_Please_fill_the_Email()"
});
formatter.result({
  "duration": 864745900,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d78.0.3904.70)\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027DIN77003756\u0027, ip: \u002710.219.34.208\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_181\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 78.0.3904.70, chrome: {chromedriverVersion: 77.0.3865.40 (f484704e052e0..., userDataDir: C:\\Users\\nifasa\\AppData\\Loc...}, goog:chromeOptions: {debuggerAddress: localhost:51705}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify}\nSession ID: bdb7a09460fcffcf8c39e4bc9dc9e0eb\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat com.cap.PersonalDetail.StepDefinition.display_Please_fill_the_Email(StepDefinition.java:98)\r\n\tat ✽.Then display \u0027Please fill the Email\u0027(C:/Users/nifasa/Desktop/Testing1/personalDetails/src/test/resource/Features/Personal.feature:27)\r\n",
  "status": "failed"
});
formatter.before({
  "duration": 5702368900,
  "status": "passed"
});
formatter.scenario({
  "line": 29,
  "name": "Invalid Mobileno",
  "description": "",
  "id": "personaldetails;invalid-mobileno",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 30,
  "name": "user is on \u0027PersonalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 31,
  "name": "user enters invalid mobile number",
  "keyword": "When "
});
formatter.step({
  "line": 32,
  "name": "display \u0027Please fill Mobile No.\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_PersonalDetails_page()"
});
formatter.result({
  "duration": 4820919100,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_invalid_mobile_number()"
});
formatter.result({
  "duration": 376039000,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.display_Please_fill_Mobile_No()"
});
formatter.result({
  "duration": 4825200,
  "error_message": "org.junit.ComparisonFailure: expected:\u003cPlease fill the [Mobile] No.\u003e but was:\u003cPlease fill the [Contact] No.\u003e\r\n\tat org.junit.Assert.assertEquals(Assert.java:115)\r\n\tat org.junit.Assert.assertEquals(Assert.java:144)\r\n\tat com.cap.PersonalDetail.StepDefinition.display_Please_fill_Mobile_No(StepDefinition.java:117)\r\n\tat ✽.Then display \u0027Please fill Mobile No.\u0027(C:/Users/nifasa/Desktop/Testing1/personalDetails/src/test/resource/Features/Personal.feature:32)\r\n",
  "status": "failed"
});
formatter.before({
  "duration": 5972129400,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "Invalid Line1",
  "description": "",
  "id": "personaldetails;invalid-line1",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "user is on \u0027PersonalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 36,
  "name": "user does not enter address",
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "display \u0027Please Enter Address\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_PersonalDetails_page()"
});
formatter.result({
  "duration": 400704400,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_does_not_enter_address()"
});
formatter.result({
  "duration": 540232700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.display_Please_Enter_Address()"
});
formatter.result({
  "duration": 7973700,
  "error_message": "org.openqa.selenium.UnhandledAlertException: unexpected alert open: {Alert text : Please fill the Contact No.}\n  (Session info: chrome\u003d78.0.3904.70): Please fill the Contact No.\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027DIN77003756\u0027, ip: \u002710.219.34.208\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_181\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 78.0.3904.70, chrome: {chromedriverVersion: 77.0.3865.40 (f484704e052e0..., userDataDir: C:\\Users\\nifasa\\AppData\\Loc...}, goog:chromeOptions: {debuggerAddress: localhost:51758}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify}\nSession ID: 42c29d32c51c420147ebdeda7df1aabe\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:120)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.execute(RemoteWebElement.java:276)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.sendKeys(RemoteWebElement.java:100)\r\n\tat sun.reflect.GeneratedMethodAccessor4.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:51)\r\n\tat com.sun.proxy.$Proxy17.sendKeys(Unknown Source)\r\n\tat com.cap.PageBean.PersonalPage.setFirstName(PersonalPage.java:85)\r\n\tat com.cap.PersonalDetail.StepDefinition.display_Please_Enter_Address(StepDefinition.java:135)\r\n\tat ✽.Then display \u0027Please Enter Address\u0027(C:/Users/nifasa/Desktop/Testing1/personalDetails/src/test/resource/Features/Personal.feature:37)\r\n",
  "status": "failed"
});
formatter.before({
  "duration": 3700558700,
  "status": "passed"
});
formatter.scenario({
  "line": 39,
  "name": "Invalid Line2",
  "description": "",
  "id": "personaldetails;invalid-line2",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 40,
  "name": "user is on \u0027PersonalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 41,
  "name": "user does not enter address",
  "keyword": "When "
});
formatter.step({
  "line": 42,
  "name": "display \u0027Please Enter Address\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_PersonalDetails_page()"
});
formatter.result({
  "duration": 115527000,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_does_not_enter_address()"
});
formatter.result({
  "duration": 529010300,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.display_Please_Enter_Address()"
});
formatter.result({
  "duration": 6613700,
  "error_message": "org.openqa.selenium.UnhandledAlertException: unexpected alert open: {Alert text : Please fill the Contact No.}\n  (Session info: chrome\u003d78.0.3904.70): Please fill the Contact No.\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027DIN77003756\u0027, ip: \u002710.219.34.208\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_181\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 78.0.3904.70, chrome: {chromedriverVersion: 77.0.3865.40 (f484704e052e0..., userDataDir: C:\\Users\\nifasa\\AppData\\Loc...}, goog:chromeOptions: {debuggerAddress: localhost:51777}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify}\nSession ID: bbf96ef55a06dbacaf6e4541b71cbae0\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:120)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.execute(RemoteWebElement.java:276)\r\n\tat org.openqa.selenium.remote.RemoteWebElement.sendKeys(RemoteWebElement.java:100)\r\n\tat sun.reflect.GeneratedMethodAccessor4.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:51)\r\n\tat com.sun.proxy.$Proxy17.sendKeys(Unknown Source)\r\n\tat com.cap.PageBean.PersonalPage.setFirstName(PersonalPage.java:85)\r\n\tat com.cap.PersonalDetail.StepDefinition.display_Please_Enter_Address(StepDefinition.java:135)\r\n\tat ✽.Then display \u0027Please Enter Address\u0027(C:/Users/nifasa/Desktop/Testing1/personalDetails/src/test/resource/Features/Personal.feature:42)\r\n",
  "status": "failed"
});
formatter.before({
  "duration": 6754953500,
  "status": "passed"
});
formatter.scenario({
  "line": 44,
  "name": "Invalid city",
  "description": "",
  "id": "personaldetails;invalid-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 45,
  "name": "user is on \u0027PersonalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 46,
  "name": "user enters invalid City",
  "keyword": "When "
});
formatter.step({
  "line": 47,
  "name": "display \u0027Please fill City\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_PersonalDetails_page()"
});
formatter.result({
  "duration": 3111976500,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_invalid_City()"
});
formatter.result({
  "duration": 2201944600,
  "error_message": "org.openqa.selenium.WebDriverException: chrome not reachable\n  (Session info: chrome\u003d78.0.3904.70)\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027DIN77003756\u0027, ip: \u002710.219.34.208\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_181\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 78.0.3904.70, chrome: {chromedriverVersion: 77.0.3865.40 (f484704e052e0..., userDataDir: C:\\Users\\nifasa\\AppData\\Loc...}, goog:chromeOptions: {debuggerAddress: localhost:51799}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify}\nSession ID: 13816a9abb8c354c97bdcfd1426d7c59\n*** Element info: {Using\u003did, value\u003dtxtFirstName}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:322)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementById(RemoteWebDriver.java:368)\r\n\tat org.openqa.selenium.By$ById.findElement(By.java:188)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:314)\r\n\tat org.openqa.selenium.support.pagefactory.DefaultElementLocator.findElement(DefaultElementLocator.java:69)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:38)\r\n\tat com.sun.proxy.$Proxy17.sendKeys(Unknown Source)\r\n\tat com.cap.PageBean.PersonalPage.setFirstName(PersonalPage.java:85)\r\n\tat com.cap.PersonalDetail.StepDefinition.user_enters_invalid_City(StepDefinition.java:146)\r\n\tat ✽.When user enters invalid City(C:/Users/nifasa/Desktop/Testing1/personalDetails/src/test/resource/Features/Personal.feature:46)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "StepDefinition.display_Please_fill_City()"
});
formatter.result({
  "status": "skipped"
});
formatter.before({
  "duration": 5880931500,
  "status": "passed"
});
formatter.scenario({
  "line": 49,
  "name": "Invalid State",
  "description": "",
  "id": "personaldetails;invalid-state",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 50,
  "name": "user is on \u0027PersonalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 51,
  "name": "user enters invalid State",
  "keyword": "When "
});
formatter.step({
  "line": 52,
  "name": "display \u0027Please fill the State\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_PersonalDetails_page()"
});
formatter.result({
  "duration": 5047229200,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_invalid_State()"
});
formatter.result({
  "duration": 2197535700,
  "error_message": "org.openqa.selenium.WebDriverException: chrome not reachable\n  (Session info: chrome\u003d78.0.3904.70)\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027DIN77003756\u0027, ip: \u002710.219.34.208\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_181\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 78.0.3904.70, chrome: {chromedriverVersion: 77.0.3865.40 (f484704e052e0..., userDataDir: C:\\Users\\nifasa\\AppData\\Loc...}, goog:chromeOptions: {debuggerAddress: localhost:51850}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify}\nSession ID: 73f3c0e87f8e2a7be3420ed13a68462f\n*** Element info: {Using\u003did, value\u003dtxtFirstName}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\r\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:322)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementById(RemoteWebDriver.java:368)\r\n\tat org.openqa.selenium.By$ById.findElement(By.java:188)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:314)\r\n\tat org.openqa.selenium.support.pagefactory.DefaultElementLocator.findElement(DefaultElementLocator.java:69)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:38)\r\n\tat com.sun.proxy.$Proxy17.sendKeys(Unknown Source)\r\n\tat com.cap.PageBean.PersonalPage.setFirstName(PersonalPage.java:85)\r\n\tat com.cap.PersonalDetail.StepDefinition.user_enters_invalid_State(StepDefinition.java:165)\r\n\tat ✽.When user enters invalid State(C:/Users/nifasa/Desktop/Testing1/personalDetails/src/test/resource/Features/Personal.feature:51)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "StepDefinition.display_Please_fill_the_State()"
});
formatter.result({
  "status": "skipped"
});
formatter.before({
  "duration": 7576659100,
  "status": "passed"
});
formatter.scenario({
  "line": 55,
  "name": "Validate the next link",
  "description": "",
  "id": "personaldetails;validate-the-next-link",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 56,
  "name": "user is on \u0027PersonalDetails\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 57,
  "name": "user clicks the Next link",
  "keyword": "When "
});
formatter.step({
  "line": 58,
  "name": "it displays \u0027Personal details are validated and accepted successfully.\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 59,
  "name": "verify it is on \u0027EducationalDetails\u0027 page",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefinition.user_is_on_PersonalDetails_page()"
});
formatter.result({
  "duration": 1488874900,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_clicks_the_Next_link()"
});
formatter.result({
  "duration": 222731300,
  "error_message": "java.lang.NullPointerException\r\n\tat sun.reflect.GeneratedMethodAccessor4.invoke(Unknown Source)\r\n\tat sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)\r\n\tat java.lang.reflect.Method.invoke(Unknown Source)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:51)\r\n\tat com.sun.proxy.$Proxy17.sendKeys(Unknown Source)\r\n\tat com.cap.PageBean.PersonalPage.setFirstName(PersonalPage.java:85)\r\n\tat com.cap.PersonalDetail.StepDefinition.user_clicks_the_Next_link(StepDefinition.java:185)\r\n\tat ✽.When user clicks the Next link(C:/Users/nifasa/Desktop/Testing1/personalDetails/src/test/resource/Features/Personal.feature:57)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "StepDefinition.it_displays_Personal_details_are_validated_and_accepted_successfully()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDefinition.verify_it_is_on_EducationalDetails_page()"
});
formatter.result({
  "status": "skipped"
});
});