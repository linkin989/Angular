package com.cap.Tours;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class StepDefinition {
	
	
	@Given("^the user is on the newtours home page$")
	public void the_user_is_on_the_newtours_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the user should Enter Login Credential of \"([^\"]*)\" & \"([^\"]*)\"$")
	public void the_user_should_Enter_Login_Credential_of(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the user should Click on Signin button$")
	public void the_user_should_Click_on_Signin_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^The user must be in registration page$")
	public void the_user_must_be_in_registration_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^select the passenger count$")
	public void select_the_passenger_count(DataTable arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
	    throw new PendingException();
	}

	@Then("^get the \"([^\"]*)\" and \"([^\"]*)\" location$")
	public void get_the_and_location(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the user should Click on Continue booking the flight ticket\\.$")
	public void the_user_should_Click_on_Continue_booking_the_flight_ticket() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


	
	
	

}
