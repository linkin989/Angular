package com.cap.Tours;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		
		features= {"C:\\Users\\nifasa\\Desktop\\Testing1\\NewTours\\src\\test\\resource\\features\\Tours.feature"},
		 glue= {"com.cap.Tours"},
		   dryRun=true,
		   strict=true,
		   monochrome=true,
		 format = {"pretty" , "html:test-output"}
		)





public class TestRunner {

}
