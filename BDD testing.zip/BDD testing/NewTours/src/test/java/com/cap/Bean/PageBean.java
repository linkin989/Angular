package com.cap.Bean;

public class PageBean {

}
