$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/nifasa/Desktop/Testing1/NewTours/src/test/resource/features/Tours.feature");
formatter.feature({
  "line": 1,
  "name": "Validate the newtours application to book a flight ticket",
  "description": "",
  "id": "validate-the-newtours-application-to-book-a-flight-ticket",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 12,
  "name": "Search as Automation testing and book the flight ticket",
  "description": "",
  "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 14,
  "name": "The user must be in registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 16
    },
    {
      "cells": [
        "2"
      ],
      "line": 17
    },
    {
      "cells": [
        "3"
      ],
      "line": 18
    },
    {
      "cells": [
        "4"
      ],
      "line": 19
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 20,
  "name": "get the \"\u003cDeparture\u003e\" and \"\u003cArrival\u003e\" location",
  "keyword": "Then "
});
formatter.step({
  "line": 21,
  "name": "the user should Click on Continue booking the flight ticket.",
  "keyword": "Then "
});
formatter.examples({
  "line": 25,
  "name": "",
  "description": "",
  "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;",
  "rows": [
    {
      "cells": [
        "Departure",
        "Arrival"
      ],
      "line": 26,
      "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;1"
    },
    {
      "cells": [
        "London",
        "Paris"
      ],
      "line": 27,
      "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;2"
    },
    {
      "cells": [
        "Paris",
        "London"
      ],
      "line": 28,
      "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;3"
    },
    {
      "cells": [
        "New York",
        "Paris"
      ],
      "line": 29,
      "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;4"
    },
    {
      "cells": [
        "London",
        "Zurich"
      ],
      "line": 30,
      "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;5"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 5,
  "name": "The user must be in login page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "the user is on the newtours home page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "the user should Enter Login Credential of \"mercury\" \u0026 \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "the user should Click on Signin button",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.the_user_is_on_the_newtours_home_page()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "mercury",
      "offset": 43
    },
    {
      "val": "mercury",
      "offset": 55
    }
  ],
  "location": "StepDefinition.the_user_should_Enter_Login_Credential_of(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDefinition.the_user_should_Click_on_Signin_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 27,
  "name": "Search as Automation testing and book the flight ticket",
  "description": "",
  "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 14,
  "name": "The user must be in registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 16
    },
    {
      "cells": [
        "2"
      ],
      "line": 17
    },
    {
      "cells": [
        "3"
      ],
      "line": 18
    },
    {
      "cells": [
        "4"
      ],
      "line": 19
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 20,
  "name": "get the \"London\" and \"Paris\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 21,
  "name": "the user should Click on Continue booking the flight ticket.",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.the_user_must_be_in_registration_page()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDefinition.select_the_passenger_count(DataTable)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "London",
      "offset": 9
    },
    {
      "val": "Paris",
      "offset": 22
    }
  ],
  "location": "StepDefinition.get_the_and_location(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDefinition.the_user_should_Click_on_Continue_booking_the_flight_ticket()"
});
formatter.result({
  "status": "skipped"
});
formatter.background({
  "line": 5,
  "name": "The user must be in login page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "the user is on the newtours home page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "the user should Enter Login Credential of \"mercury\" \u0026 \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "the user should Click on Signin button",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.the_user_is_on_the_newtours_home_page()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "mercury",
      "offset": 43
    },
    {
      "val": "mercury",
      "offset": 55
    }
  ],
  "location": "StepDefinition.the_user_should_Enter_Login_Credential_of(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDefinition.the_user_should_Click_on_Signin_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 28,
  "name": "Search as Automation testing and book the flight ticket",
  "description": "",
  "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 14,
  "name": "The user must be in registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 16
    },
    {
      "cells": [
        "2"
      ],
      "line": 17
    },
    {
      "cells": [
        "3"
      ],
      "line": 18
    },
    {
      "cells": [
        "4"
      ],
      "line": 19
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 20,
  "name": "get the \"Paris\" and \"London\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 21,
  "name": "the user should Click on Continue booking the flight ticket.",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.the_user_must_be_in_registration_page()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDefinition.select_the_passenger_count(DataTable)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "Paris",
      "offset": 9
    },
    {
      "val": "London",
      "offset": 21
    }
  ],
  "location": "StepDefinition.get_the_and_location(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDefinition.the_user_should_Click_on_Continue_booking_the_flight_ticket()"
});
formatter.result({
  "status": "skipped"
});
formatter.background({
  "line": 5,
  "name": "The user must be in login page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "the user is on the newtours home page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "the user should Enter Login Credential of \"mercury\" \u0026 \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "the user should Click on Signin button",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.the_user_is_on_the_newtours_home_page()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "mercury",
      "offset": 43
    },
    {
      "val": "mercury",
      "offset": 55
    }
  ],
  "location": "StepDefinition.the_user_should_Enter_Login_Credential_of(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDefinition.the_user_should_Click_on_Signin_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 29,
  "name": "Search as Automation testing and book the flight ticket",
  "description": "",
  "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 14,
  "name": "The user must be in registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 16
    },
    {
      "cells": [
        "2"
      ],
      "line": 17
    },
    {
      "cells": [
        "3"
      ],
      "line": 18
    },
    {
      "cells": [
        "4"
      ],
      "line": 19
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 20,
  "name": "get the \"New York\" and \"Paris\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 21,
  "name": "the user should Click on Continue booking the flight ticket.",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.the_user_must_be_in_registration_page()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDefinition.select_the_passenger_count(DataTable)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "New York",
      "offset": 9
    },
    {
      "val": "Paris",
      "offset": 24
    }
  ],
  "location": "StepDefinition.get_the_and_location(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDefinition.the_user_should_Click_on_Continue_booking_the_flight_ticket()"
});
formatter.result({
  "status": "skipped"
});
formatter.background({
  "line": 5,
  "name": "The user must be in login page",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 6,
  "name": "the user is on the newtours home page",
  "keyword": "Given "
});
formatter.step({
  "line": 7,
  "name": "the user should Enter Login Credential of \"mercury\" \u0026 \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "the user should Click on Signin button",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.the_user_is_on_the_newtours_home_page()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "mercury",
      "offset": 43
    },
    {
      "val": "mercury",
      "offset": 55
    }
  ],
  "location": "StepDefinition.the_user_should_Enter_Login_Credential_of(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDefinition.the_user_should_Click_on_Signin_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 30,
  "name": "Search as Automation testing and book the flight ticket",
  "description": "",
  "id": "validate-the-newtours-application-to-book-a-flight-ticket;search-as-automation-testing-and-book-the-flight-ticket;;5",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 14,
  "name": "The user must be in registration page",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 16
    },
    {
      "cells": [
        "2"
      ],
      "line": 17
    },
    {
      "cells": [
        "3"
      ],
      "line": 18
    },
    {
      "cells": [
        "4"
      ],
      "line": 19
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 20,
  "name": "get the \"London\" and \"Zurich\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 21,
  "name": "the user should Click on Continue booking the flight ticket.",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.the_user_must_be_in_registration_page()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDefinition.select_the_passenger_count(DataTable)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "arguments": [
    {
      "val": "London",
      "offset": 9
    },
    {
      "val": "Zurich",
      "offset": 22
    }
  ],
  "location": "StepDefinition.get_the_and_location(String,String)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "StepDefinition.the_user_should_Click_on_Continue_booking_the_flight_ticket()"
});
formatter.result({
  "status": "skipped"
});
});