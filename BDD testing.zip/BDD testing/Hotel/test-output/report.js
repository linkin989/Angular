$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/nifasa/Desktop/Testing1/Hotel/src/test/resource/Booking/Booking.feature");
formatter.feature({
  "line": 1,
  "name": "HotelBooking",
  "description": "",
  "id": "hotelbooking",
  "keyword": "Feature"
});
formatter.before({
  "duration": 5371752000,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "Invalid first name",
  "description": "",
  "id": "hotelbooking;invalid-first-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "user enters invalid first name",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "displays \u0027Please fill the first Name\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 1128909200,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_invalid_first_name()"
});
formatter.result({
  "duration": 221413300,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.displays_Please_fill_the_first_Name()"
});
formatter.result({
  "duration": 606622300,
  "status": "passed"
});
formatter.before({
  "duration": 1423489400,
  "status": "passed"
});
formatter.scenario({
  "line": 9,
  "name": "Invalid last name",
  "description": "",
  "id": "hotelbooking;invalid-last-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 10,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "user enters invalid last name",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "displays \u0027Please fill the Last Name\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 4684999000,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_invalid_last_name()"
});
formatter.result({
  "duration": 411428100,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.displays_Please_fill_the_Last_Name()"
});
formatter.result({
  "duration": 415874900,
  "status": "passed"
});
formatter.before({
  "duration": 1853481800,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Invalid Email",
  "description": "",
  "id": "hotelbooking;invalid-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "user enters invalid email",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "display \u0027Please fill the Email\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 1914538100,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_invalid_email()"
});
formatter.result({
  "duration": 413610200,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.display_Please_fill_the_Email()"
});
formatter.result({
  "duration": 443576200,
  "status": "passed"
});
formatter.before({
  "duration": 2093650800,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "Invalid Mobile Number",
  "description": "",
  "id": "hotelbooking;invalid-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 21,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 22,
  "name": "user enters invalid mobile number",
  "keyword": "When "
});
formatter.step({
  "line": 23,
  "name": "display \u0027Please fill Mobile No.\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
