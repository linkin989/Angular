package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class LoginPage {
	
	WebDriver driver;
	
	
	@FindBy(name="userName")
	@CacheLookup
	WebElement userName;
	
	
	@FindBy( name="userPwd")
	@CacheLookup
	WebElement password;

	@FindBy(className="btn")
	@CacheLookup
	WebElement loginButton;
	
	
	
	@FindBy(id="userErrMsg")
	@CacheLookup
	WebElement usernameError;
	
	
	@FindBy(id="pwdErrMsg")
	@CacheLookup
	WebElement passwordError;


	public WebDriver getDriver() {
		return driver;
	}


	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}


	public WebElement getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}


	public WebElement getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password.sendKeys(password);
	}


	public WebElement getLoginButton() {
		return loginButton;
	}


	public void setLoginButton() {
		this.loginButton.click();
	}

	public WebElement getUsernameError() {
		return usernameError;
	}

	public void setUsernameError(String usernameError) {
		this.usernameError.sendKeys(usernameError);
	}

	
	public WebElement getPasswordError() {
		return passwordError;
	}

	
	public void setPasswordError(String passwordError) {
		this.passwordError.sendKeys(passwordError);
	}


	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
