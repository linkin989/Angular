package com.cap.Login;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import com.cap.bean.loginBean;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	
	
	WebDriver Driver;

	loginBean login;
	

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\nifasa\\Desktop\\chromedriver.exe");

		Driver = new ChromeDriver();
	}
	
	@After
	public void closee() {
		Driver.quit();
	}
	
	
	
	@Given("^user is on 'Login' page$")
	public void user_is_on_Login_page() throws Throwable {
		Driver.get("C:\\Users\\nifasa\\Desktop\\CapStore\\src\\app\\customer-login\\customer-login.component.html");
		login = new loginBean(Driver);
	    
	}

	@When("^user enters invalid  email$")
	public void user_enters_invalid_email() throws Throwable {
	    login.setEmail("");
	    login.setButton();
	  
	}

	@Then("^displays 'Please fill the  email'$")
	public void displays_Please_fill_the_email() throws Throwable {
		WebElement email = Driver.findElement(By.id("reg_Email"));
		Assert.assertEquals("Please fill out this field.", email); 
	   
	}

	@When("^user enters invalid  password$")
	public void user_enters_invalid_password() throws Throwable {
		  login.setEmail("khannifaz@gmail.com");
		  login.setPassword("");
		  login.setButton();
	   
	}

	@Then("^displays 'Please fill the  Password'$")
	public void displays_Please_fill_the_Password() throws Throwable {
		WebElement password = Driver.findElement(By.id("reg_Password")); 
		Assert.assertEquals("Please fill out this field.", password);  
	}

	@When("^user enters valid  details$")
	public void user_enters_valid_details() throws Throwable {
		  login.setEmail("khannifaz@gmail.com");
		  login.setPassword("Nifaz@1234");
		  login.setButton();
	   
	}

	@Then("^displays 'Login Completed!!!'$")
	public void displays_Login_Completed() throws Throwable {
		Driver.get("C:\\Users\\nifasa\\Desktop\\CapStore\\src\\app\\customer-login\\customer-login.component.html");   
	   
	}



}
