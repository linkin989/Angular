package com.cap.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class loginBean {
	
	WebDriver Driver;
	
	
	@FindBy( id="reg_Email")
	@CacheLookup
	WebElement email;

	@FindBy(id="reg_Password")
	@CacheLookup
	WebElement password;
	
	@FindBy(id="Login_btn")
	@CacheLookup
	WebElement button;
	

	public WebDriver getDriver() {
		return Driver;
	}

	
	
	public void setDriver(WebDriver driver) {
		Driver = driver;
	}
	
	
	
	public WebElement getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	
	
	
	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	
	
	
	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		this.button.click();
	}



	public loginBean(WebDriver driver) {
		super();
		Driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
	
	
	
	
	
	

}
