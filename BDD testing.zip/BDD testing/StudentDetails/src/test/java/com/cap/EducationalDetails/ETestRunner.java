package com.cap.EducationalDetails;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\Users\\nifasa\\Downloads\\StudentDetails\\src\\test\\resource\\EducationalDetails.feature"},
		glue={"com.cap.EducationalDetails"},
		dryRun=false,
		strict=true,
	    monochrome=false
		)

public class ETestRunner {

}
