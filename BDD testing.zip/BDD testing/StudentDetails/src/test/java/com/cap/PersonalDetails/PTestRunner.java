package com.cap.PersonalDetails;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\Users\\nifasa\\Downloads\\StudentDetails\\src\\test\\resource\\PersonalDetails.feature"},
		glue={"com.cap.PersonalDetails"},
		dryRun=false,
		strict=true,
	    monochrome=false
		)
public class PTestRunner {

}
