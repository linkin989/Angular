package com.cap.Google;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class StepDefinition {
	
	WebDriver Driver;
	String Search_term;
	
	@Given("^Goto Google\\.co\\.in url$")
	public void goto_Google_co_in_url()  {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\nifasa\\Desktop\\chrome\\chromedriver.exe");
		Driver = new ChromeDriver();
		Driver.get("https://www.google.com/");
	   
	}

	@Then("^Search for keyword as Automation Testing$")
	public void search_for_keyword_as_Automation_Testing() {
	 
		Search_term = "Automation testing";
	    Driver.findElement(By.xpath("//input[@title = 'Search']")).sendKeys(Search_term);
		
	  
	}

	@Then("^Click on Search button$")
	public void click_on_Search_button()  {
		 Driver.findElement(By.xpath("//input[@title = 'Search']")).submit();
	  
	}

	@Then("^Get the title should be same as search term$")
	public void get_the_title_should_be_same_as_search_term()  {
		  
		 String title = Driver.getTitle();
	        if(title.contains(Search_term)) {
	            System.out.println("Title is same");
		
		
	}else {
		 System.out.println("Title is not same");
	}
	        Driver.close();
	        
	}
	
	}


