$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/nifasa/Desktop/Testing1/Google/src/test/resource/Feature/file.feature");
formatter.feature({
  "line": 1,
  "name": "validating the Google search engine",
  "description": "",
  "id": "validating-the-google-search-engine",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 4,
  "name": "Search for the \"google\"",
  "description": "",
  "id": "validating-the-google-search-engine;search-for-the-\"google\"",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 7,
  "name": "Goto Google.co.in url",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "Search for keyword as Automation Testing",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Click on Search button",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "Get the title should be same as search term",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.goto_Google_co_in_url()"
});
formatter.result({
  "duration": 30954748600,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.search_for_keyword_as_Automation_Testing()"
});
formatter.result({
  "duration": 2174814500,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.click_on_Search_button()"
});
formatter.result({
  "duration": 7905278800,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.get_the_title_should_be_same_as_search_term()"
});
formatter.result({
  "duration": 3701354400,
  "status": "passed"
});
});