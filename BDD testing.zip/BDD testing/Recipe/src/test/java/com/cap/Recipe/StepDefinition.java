package com.cap.Recipe;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cap.PageFactory.RecipePage;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	
	
	WebDriver Driver;
	
	RecipePage Recipe;
	
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\nifasa\\Desktop\\chromedriver.exe");

		Driver = new ChromeDriver();
	}
	
	
	@After
	public void closee() {
		Driver.quit();
	}
	
	

	/*
	@Given("^user is on the Recipe_class_registration form$")
	public void user_is_on_the_Recipe_class_registration_form() throws Throwable {
		Driver.get("C:\\Users\\nifasa\\Desktop\\Re\\Recipe_class_registration.html");
		Recipe = new RecipePage(Driver);
	}

	@When("^user enters into Html Page$")
	public void user_enters_into_Html_Page() throws Throwable {
		Thread.sleep(1000); 	}

	@Then("^the html page pause for (\\d+)sec$")
	public void the_html_page_pause_for_sec(int arg1) throws Throwable {
		Thread.sleep(1000);
	}

	@Then("^verify the title of the  'Online Cooking Class Enquiry Form'$")
	public void verify_the_title_of_the_Online_Cooking_Class_Enquiry_Form() throws Throwable {
		String expMsg="Online Cooking Class Enquiry Form";
        String title=Driver.getTitle();
	    Assert.assertEquals(expMsg,title);
	}

	@Then("^verify the text on the webpage 'Online Cooking School-Taste of Home'$")
	public void verify_the_text_on_the_webpage_Online_Cooking_School_Taste_of_Home() throws Throwable {
		String expectedMsg="Recipe Class Enquiry Form";
		String Heading = Driver.findElement(By.xpath("//span[@class='auto-style4']")).getAttribute("validationMessage");
		Assert.assertEquals( expectedMsg,Heading);
	}
*/

	@Given("^user is on the Recipe_class_registration form$")
	public void user_is_on_the_Recipe_class_registration_form() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters into Html Page$")
	public void user_enters_into_Html_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the html page pause for (\\d+)sec$")
	public void the_html_page_pause_for_sec(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^verify the title of the  'Online Cooking Class Enquiry Form'$")
	public void verify_the_title_of_the_Online_Cooking_Class_Enquiry_Form() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^verify the text on the webpage 'Online Cooking School-Taste of Home'$")
	public void verify_the_text_on_the_webpage_Online_Cooking_School_Taste_of_Home() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}



}
