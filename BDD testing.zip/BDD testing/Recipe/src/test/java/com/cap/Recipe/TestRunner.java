package com.cap.Recipe;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\Users\\nifasa\\Desktop\\Testing1\\Recipe\\src\\resource\\test\\Feature\\Recipe.feature"},
		glue={" com.cap.Recipe"},
		dryRun=true,
		strict=true
		)

public class TestRunner {

}
