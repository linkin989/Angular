package com.cap.PageFactory;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.support.PageFactory;

public class RecipePage {
	
	
	WebDriver Driver;
	
	
	

	public WebDriver getDriver() {
		return Driver;
	}

	public void setDriver(WebDriver driver) {
		Driver = driver;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

	public RecipePage(WebDriver driver) {
		super();
		Driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
	
	
	
	
	

}
