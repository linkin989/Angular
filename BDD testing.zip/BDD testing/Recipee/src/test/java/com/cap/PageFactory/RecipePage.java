package com.cap.PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RecipePage {
	
	
	WebDriver Driver;
	
	
	
	
	@FindBy(id="fname")
	@CacheLookup
	WebElement firstname;
	
	
	@FindBy(id="lname")
	@CacheLookup
	WebElement lastname;
	
	
	@FindBy(id="emails")
	@CacheLookup
	WebElement email;
	
	@FindBy(id="mobile")
	@CacheLookup
	WebElement mobilenumber;
	
	
	@FindBy(name="D6")
	@CacheLookup
	WebElement Category;
	
	@FindBy(name="D5")
	@CacheLookup
	WebElement City;
	
	
	@FindBy(xpath="//a[@href='msg.html']")
	@CacheLookup
	WebElement msghref;
	
	@FindBy(id="enqdetails")
	@CacheLookup
	WebElement enquirydetails;
	
	
	
	public WebElement getMsghref() {
		return msghref;
	}

	public void setMsghref() {
		this.msghref.click();
	}

	@FindBy(xpath="/html/body/form/table/tbody/tr[8]/td[2]/select")
	@CacheLookup
	WebElement Mode;
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[9]/td[2]/select")
	@CacheLookup
	WebElement TimeDuration;
	
	
	
	@FindBy(id="Submit1")
	@CacheLookup
	WebElement Enquire ;
	
	
	
	
	
	
	

	public WebElement getEnquire() {
		return Enquire;
	}

	public void setEnquire() {
		Enquire.click();
	}

	public WebDriver getDriver() {
		return Driver;
	}

	public void setDriver(WebDriver driver) {
		Driver = driver;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

	public WebElement getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname.sendKeys(firstname);
	}

	public WebElement getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobilenumber() {
		return mobilenumber;
	}

	public void setMobilenumber(String mobilenumber) {
		this.mobilenumber.sendKeys(mobilenumber);
	}
	
	
	
	
	
	
	

	public WebElement getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category.sendKeys(category);
	}

	public WebElement getCity() {
		return City;
	}

	public void setCity(String city) {
		City.sendKeys(city);
	}

	public WebElement getMode() {
		return Mode;
	}

	public void setMode(String mode) {
		Mode.sendKeys(mode);
	}

	public WebElement getTimeDuration() {
		return TimeDuration;
	}

	public void setTimeDuration(String timeDuration) {
		TimeDuration .sendKeys(timeDuration);
	}
	
	
	
	
	

	public WebElement getEnquirydetails() {
		return enquirydetails;
	}

	public void setEnquirydetails(String enquirydetails) {
		this.enquirydetails.sendKeys("enquirydetails");
	}

	public RecipePage(WebDriver driver) {
		super();
		Driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
	
	
	
	
	

}
