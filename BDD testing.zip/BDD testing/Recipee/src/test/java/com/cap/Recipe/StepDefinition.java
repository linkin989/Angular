package com.cap.Recipe;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cap.PageFactory.RecipePage;
import com.cap.PageFactory.msgPage;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	
	
	WebDriver Driver;
	
	RecipePage Recipe;
	msgPage msg;
	
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\nifasa\\Desktop\\chromedriver.exe");

		Driver = new ChromeDriver();
	}
	
	
	@After
	public void closee() {
		Driver.quit();
	}
	
	

	

	@Given("^user is on the Recipe_class_registration form$")
	public void user_is_on_the_Recipe_class_registration_form() throws Throwable {
		Driver.get("C:\\Users\\nifasa\\Desktop\\Re\\Recipe_class_registration.html");
		Recipe = new RecipePage(Driver);
	}

	@When("^user enters into Html Page$")
	public void user_enters_into_Html_Page() throws Throwable {
		Thread.sleep(1000); 
	}

	@Then("^the html page pause for (\\d+)sec$")
	public void the_html_page_pause_for_sec(int arg1) throws Throwable {
		Thread.sleep(1000);
	}

	@Then("^verify the title of the  'Online Cooking Class Enquiry Form'$")
	public void verify_the_title_of_the_Online_Cooking_Class_Enquiry_Form() throws Throwable {
		String expMsg="Online Cooking Class Enquiry Form";
        String title=Driver.getTitle();
	    Assert.assertEquals(expMsg,title);
	}

	@Then("^verify the text on the webpage 'Online Cooking School-Taste of Home'$")
	public void verify_the_text_on_the_webpage_Online_Cooking_School_Taste_of_Home() throws Throwable {
		String expectedMsg="Online Cooking School";
		WebElement Heading = Driver.findElement(By.xpath("//span[@class='auto-style4']"));
		Assert.assertEquals( expectedMsg,Heading);
	}

	@When("^user click on the hyperlink 'Download our Recipe Class Broucher form'$")
	public void user_click_on_the_hyperlink_Download_our_Recipe_Class_Broucher_form() throws Throwable {
	   Recipe.setMsghref();
	   
	    
	}

	@Then("^pause the Execution for '(\\d+)sec'$")
	public void pause_the_Execution_for_sec(int arg1) throws Throwable {
		Thread.sleep(1500);
		Driver.get("C:\\Users\\nifasa\\Desktop\\Re\\msg.html");
		
	   
	}

	@Then("^Verify the text'Recipe Broucher is sent to your registered mailid'$")
	public void verify_the_text_Recipe_Broucher_is_sent_to_your_registered_mailid() throws Throwable {
		Boolean msg=Driver.getPageSource().contains("Recipe class Brochure is sent to your registered mail id");
        Boolean expmsg=true;
        Assert.assertEquals(msg,expmsg);
        
	}

	@Given("^user is on the msg\\.html form$")
	public void user_is_on_the_msg_html_form() throws Throwable {
		Driver.get("C:\\Users\\nifasa\\Desktop\\Re\\msg.html");
		msg = new msgPage(Driver);
	}

	@When("^user clicks the hyperlink goback to registration$")
	public void user_clicks_the_hyperlink_goback_to_registration() throws Throwable {
	   msg.setMsghref();
	}

	@Then("^user navigated to registration page$")
	public void user_navigated_to_registration_page() throws Throwable {
	    Driver.get("C:\\Users\\nifasa\\Desktop\\Re\\Recipe_class_registration.html");
	}


	@When("^user inputs the first name$")
	public void user_inputs_the_first_name() throws Throwable {
	    Recipe.setFirstname("");
	    Recipe.setEnquire();
	   
	}

	@Then("^it displays 'First Name must be filled out '$")
	public void it_displays_First_Name_must_be_filled_out() throws Throwable {
		String Firstname = Driver.switchTo().alert().getText();
		Assert.assertEquals("First Name must be filled out", Firstname);
		Driver.switchTo().alert().accept();
	}

	@When("^user inputs the last name$")
	public void user_inputs_the_last_name() throws Throwable {
	  Recipe.setFirstname("Nifas");
	   Recipe.setLastname("");
	   Recipe.setEnquire();
	}

	@Then("^it displays 'Last Name must be filled out '$")
	public void it_displays_Last_Name_must_be_filled_out() throws Throwable {
		String Lastname = Driver.switchTo().alert().getText();
		Assert.assertEquals("Last Name must be filled out", Lastname);
		Driver.switchTo().alert().accept();
	}

	@When("^user inputs the Email$")
	public void user_inputs_the_Email() throws Throwable {
		 Recipe.setFirstname("Nifas");
		   Recipe.setLastname("khan");
	   Recipe.setEmail("Recipe@gmail.com");
	   Recipe.setEnquire();
	   
	}

	@When("^user inputs mobile number$")
	public void user_inputs_mobile_number() throws Throwable {
		 Recipe.setFirstname("Nifas");
		 Recipe.setLastname("khan");
	     Recipe.setEmail("Recipe@gmail.com");
	     Recipe.setMobilenumber("vgghh");
	     Recipe.setEnquire();
	    
	}

	@Then("^it displays 'Enter numeric value '$")
	public void it_displays_Enter_numeric_value() throws Throwable {
		String mobilenumber = Driver.switchTo().alert().getText();
		Assert.assertEquals("Enter numeric value", mobilenumber);
		Driver.switchTo().alert().accept();
	}
	
	@When("^User Enters mobile number more than '(\\d+)dights'$")
	public void user_Enters_mobile_number_more_than_dights(int arg1) throws Throwable {
		 Recipe.setFirstname("Nifas");
		 Recipe.setLastname("khan");
	     Recipe.setEmail("Recipe@gmail.com");
	     Recipe.setMobilenumber("789486456321");
	     Recipe.setEnquire();
	}

	@Then("^it displays 'Enter the (\\d+) digit number'$")
	public void it_displays_Enter_the_digit_number(int arg1) throws Throwable {
		String mobilenumber1 = Driver.switchTo().alert().getText();
		Assert.assertEquals("Enter 10 digit Mobile number", mobilenumber1);
		Driver.switchTo().alert().accept();
	}
	
	
	@When("^select the category as 'Non-Veg'$")
	public void select_the_category_as_Non_Veg() throws Throwable {
		Recipe.setFirstname("Nifas");
		 Recipe.setLastname("khan");
	     Recipe.setEmail("Recipe@gmail.com");
	     Recipe.setMobilenumber("9745632145");
	    Recipe.setCategory("Non-Veg");
	    Recipe.setEnquire();
	}

	@When("^select the city category as 'Mumbai'$")
	public void select_the_city_category_as_Mumbai() throws Throwable {
		Recipe.setFirstname("Nifas");
		 Recipe.setLastname("khan");
	     Recipe.setEmail("Recipe@gmail.com");
	     Recipe.setMobilenumber("9745632145");
	    Recipe.setCategory("Non-Veg");
	    Recipe.setCity("Mumbai");
	    Recipe.setEnquire();
	}

	@When("^select the mode as 'In house training'$")
	public void select_the_mode_as_In_house_training() throws Throwable {
		Recipe.setFirstname("Nifas");
		 Recipe.setLastname("khan");
	     Recipe.setEmail("Recipe@gmail.com");
	     Recipe.setMobilenumber("9745632145");
	    Recipe.setCategory("Non-Veg");
	    Recipe.setCity("Mumbai");
	    Recipe.setMode("In house training");
	    Recipe.setEnquire();
	}

	@When("^select the duration as '(\\d+) months'$")
	public void select_the_duration_as_months(int arg1) throws Throwable {
		Recipe.setFirstname("Nifas");
		 Recipe.setLastname("khan");
	     Recipe.setEmail("Recipe@gmail.com");
	     Recipe.setMobilenumber("9745632145");
	     Recipe.setCategory("Non-Veg");
	     Recipe.setCity("Mumbai");
	     Recipe.setMode("In house training");
	     Recipe.setTimeDuration("6 months");
	     Recipe.setEnquire();
	}

	@When("^click the 'Enquire Now'$")
	public void click_the_Enquire_Now() throws Throwable {
	   Recipe.setEnquire();
	   
	}
	
	@Then("^is displays Enquiry 'details must be filled out'$")
	public void is_displays_Enquiry_details_must_be_filled_out() throws Throwable {
		String Enqu = Driver.switchTo().alert().getText();
		Assert.assertEquals("Enquiry details must be filled out", Enqu);
		Driver.switchTo().alert().accept();
	}

	@When("^user inputs  the details$")
	public void user_inputs_the_details() throws Throwable {
		 Recipe.setFirstname("Nifas");
		 Recipe.setLastname("khan");
	     Recipe.setEmail("Recipe@gmail.com");
	     Recipe.setMobilenumber("9745632145");
	     Recipe.setCategory("Non-Veg");
	     Recipe.setCity("Mumbai");
	     Recipe.setMode("In house training");
	     Recipe.setTimeDuration("6 months");
	     Recipe.setEnquirydetails("dfhhhgfhf");
	     Recipe.setEnquire();
	}

	@Then("^click the Enquire Now(\\d+)$")
	public void click_the_Enquire_Now(int arg1) throws Throwable {
		String Enqudetails = Driver.switchTo().alert().getText();
		Assert.assertEquals("Thank you for submitting the online recipe class Enquiry", Enqudetails);
		Driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	
	@Then("^it displays'Our location representative will contact you soon\\.'$")
	public void it_displays_Our_location_representative_will_contact_you_soon() throws Throwable {
		String expectedmsg = "Our location representative will contact you soon.";
		String msg=Driver.findElement(By.tagName("h3")).getText();
		Assert.assertEquals(expectedmsg,msg);
		
	   
	}


	
	


}
