package com.cap.PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class msgPage {
	
	
	WebDriver Driver;
	
	@FindBy(xpath="//a[@href='Recipe_class_registration.html']")
	@CacheLookup
	WebElement msghref;

	public WebDriver getDriver() {
		return Driver;
	}

	public void setDriver(WebDriver driver) {
		Driver = driver;
	}

	public WebElement getMsghref() {
		return msghref;
	}

	public void setMsghref( ) {
		this.msghref.click();
	}

	public msgPage(WebDriver driver) {
		super();
		Driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
}
