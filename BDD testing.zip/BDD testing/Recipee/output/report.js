$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/nifasa/Desktop/Testing1/Registration/test/Feature/Recipe.feature");
formatter.feature({
  "line": 1,
  "name": "Recipe",
  "description": "",
  "id": "recipe",
  "keyword": "Feature"
});
formatter.before({
  "duration": 13859876900,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "checking the title of the page",
  "description": "",
  "id": "recipe;checking-the-title-of-the-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "user is on the Recipe_class_registration form",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "user enters into Html Page",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "the html page pause for 10sec",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "verify the title of the  \u0027Online Cooking Class Enquiry Form\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "verify the text on the webpage \u0027Online Cooking School-Taste of Home\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_Recipe_class_registration_form()"
});
formatter.result({
  "duration": 8584704600,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_enters_into_Html_Page()"
});
formatter.result({
  "duration": 1000609900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "10",
      "offset": 24
    }
  ],
  "location": "StepDefinition.the_html_page_pause_for_sec(int)"
});
formatter.result({
  "duration": 1001992900,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.verify_the_title_of_the_Online_Cooking_Class_Enquiry_Form()"
});
formatter.result({
  "duration": 12924400,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.verify_the_text_on_the_webpage_Online_Cooking_School_Taste_of_Home()"
});
formatter.result({
  "duration": 21259700,
  "error_message": "java.lang.AssertionError: expected:\u003cOnline Cooking School\u003e but was:\u003c[[ChromeDriver: chrome on XP (152a2348eb32f6b1f5385de1d64fd156)] -\u003e xpath: //span[@class\u003d\u0027auto-style4\u0027]]\u003e\r\n\tat org.junit.Assert.fail(Assert.java:88)\r\n\tat org.junit.Assert.failNotEquals(Assert.java:834)\r\n\tat org.junit.Assert.assertEquals(Assert.java:118)\r\n\tat org.junit.Assert.assertEquals(Assert.java:144)\r\n\tat com.cap.Recipe.StepDefinition.verify_the_text_on_the_webpage_Online_Cooking_School_Taste_of_Home(StepDefinition.java:72)\r\n\tat ✽.Then verify the text on the webpage \u0027Online Cooking School-Taste of Home\u0027(C:/Users/nifasa/Desktop/Testing1/Registration/test/Feature/Recipe.feature:8)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 2265784900,
  "status": "passed"
});
formatter.before({
  "duration": 2195228000,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "To check the HyperLink",
  "description": "",
  "id": "recipe;to-check-the-hyperlink",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "user is on the Recipe_class_registration form",
  "keyword": "Given "
});
formatter.step({
  "line": 12,
  "name": "user click on the hyperlink \u0027Download our Recipe Class Broucher form\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "pause the Execution for \u002715sec\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 14,
  "name": "Verify the text\u0027Recipe Broucher is sent to your registered mailid\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_Recipe_class_registration_form()"
});
formatter.result({
  "duration": 3079119800,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_click_on_the_hyperlink_Download_our_Recipe_Class_Broucher_form()"
});
formatter.result({
  "duration": 463913400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "15",
      "offset": 25
    }
  ],
  "location": "StepDefinition.pause_the_Execution_for_sec(int)"
});
formatter.result({
  "duration": 1533568700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.verify_the_text_Recipe_Broucher_is_sent_to_your_registered_mailid()"
});
formatter.result({
  "duration": 19225800,
  "status": "passed"
});
formatter.after({
  "duration": 907536200,
  "status": "passed"
});
formatter.before({
  "duration": 1607664500,
  "status": "passed"
});
formatter.scenario({
  "line": 16,
  "name": "checks the hyperlink in msg.html",
  "description": "",
  "id": "recipe;checks-the-hyperlink-in-msg.html",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 17,
  "name": "user is on the msg.html form",
  "keyword": "Given "
});
formatter.step({
  "line": 18,
  "name": "user clicks the hyperlink goback to registration",
  "keyword": "When "
});
formatter.step({
  "line": 19,
  "name": "user navigated to registration page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_msg_html_form()"
});
formatter.result({
  "duration": 1343333600,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_clicks_the_hyperlink_goback_to_registration()"
});
formatter.result({
  "duration": 1172914400,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_navigated_to_registration_page()"
});
formatter.result({
  "duration": 22535400,
  "status": "passed"
});
formatter.after({
  "duration": 816843800,
  "status": "passed"
});
formatter.before({
  "duration": 1587790200,
  "status": "passed"
});
formatter.scenario({
  "line": 23,
  "name": "Enter the first name",
  "description": "",
  "id": "recipe;enter-the-first-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 24,
  "name": "user is on the Recipe_class_registration form",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "user inputs the first name",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "it displays \u0027First Name must be filled out \u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_Recipe_class_registration_form()"
});
formatter.result({
  "duration": 2378553200,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_inputs_the_first_name()"
});
formatter.result({
  "duration": 134060700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.it_displays_First_Name_must_be_filled_out()"
});
formatter.result({
  "duration": 20566200,
  "status": "passed"
});
formatter.after({
  "duration": 904927600,
  "status": "passed"
});
formatter.before({
  "duration": 2778305300,
  "status": "passed"
});
formatter.scenario({
  "line": 28,
  "name": "Enter the last name",
  "description": "",
  "id": "recipe;enter-the-last-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 29,
  "name": "user is on the Recipe_class_registration form",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "user inputs the last name",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "it displays \u0027Last Name must be filled out \u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_Recipe_class_registration_form()"
});
formatter.result({
  "duration": 3159216900,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_inputs_the_last_name()"
});
formatter.result({
  "duration": 229352700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.it_displays_Last_Name_must_be_filled_out()"
});
formatter.result({
  "duration": 13872300,
  "status": "passed"
});
formatter.after({
  "duration": 995803500,
  "status": "passed"
});
formatter.before({
  "duration": 2448919400,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "Enter the last name",
  "description": "",
  "id": "recipe;enter-the-last-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "user is on the Recipe_class_registration form",
  "keyword": "Given "
});
formatter.step({
  "line": 36,
  "name": "user inputs the last name",
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "it displays \u0027Last Name must be filled out \u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_Recipe_class_registration_form()"
});
formatter.result({
  "duration": 2089331100,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_inputs_the_last_name()"
});
formatter.result({
  "duration": 227186800,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.it_displays_Last_Name_must_be_filled_out()"
});
formatter.result({
  "duration": 17387400,
  "status": "passed"
});
formatter.after({
  "duration": 881655800,
  "status": "passed"
});
formatter.before({
  "duration": 2450351100,
  "status": "passed"
});
formatter.scenario({
  "line": 39,
  "name": "Enter the Email",
  "description": "",
  "id": "recipe;enter-the-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 40,
  "name": "user is on the Recipe_class_registration form",
  "keyword": "Given "
});
formatter.step({
  "line": 41,
  "name": "user inputs the Email",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_Recipe_class_registration_form()"
});
formatter.result({
  "duration": 2002394400,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_inputs_the_Email()"
});
formatter.result({
  "duration": 433006900,
  "status": "passed"
});
formatter.after({
  "duration": 1074928300,
  "status": "passed"
});
formatter.before({
  "duration": 2298552600,
  "status": "passed"
});
formatter.scenario({
  "line": 44,
  "name": "Enter the mobile number",
  "description": "",
  "id": "recipe;enter-the-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 45,
  "name": "user is on the Recipe_class_registration form",
  "keyword": "Given "
});
formatter.step({
  "line": 46,
  "name": "user inputs mobile number",
  "keyword": "When "
});
formatter.step({
  "line": 47,
  "name": "it displays \u0027Enter numeric value \u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_Recipe_class_registration_form()"
});
formatter.result({
  "duration": 1697630000,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_inputs_mobile_number()"
});
formatter.result({
  "duration": 492828000,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.it_displays_Enter_numeric_value()"
});
formatter.result({
  "duration": 19351000,
  "status": "passed"
});
formatter.after({
  "duration": 876194100,
  "status": "passed"
});
formatter.before({
  "duration": 2180963600,
  "status": "passed"
});
formatter.scenario({
  "line": 49,
  "name": "Enter the mobile number",
  "description": "",
  "id": "recipe;enter-the-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 50,
  "name": "user is on the Recipe_class_registration form",
  "keyword": "Given "
});
formatter.step({
  "line": 51,
  "name": "User Enters mobile number more than \u002710dights\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 52,
  "name": "it displays \u0027Enter the 10 digit number\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_Recipe_class_registration_form()"
});
formatter.result({
  "duration": 2307601200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "10",
      "offset": 37
    }
  ],
  "location": "StepDefinition.user_Enters_mobile_number_more_than_dights(int)"
});
formatter.result({
  "duration": 529776900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "10",
      "offset": 23
    }
  ],
  "location": "StepDefinition.it_displays_Enter_the_digit_number(int)"
});
formatter.result({
  "duration": 28058700,
  "status": "passed"
});
formatter.after({
  "duration": 1191517400,
  "status": "passed"
});
formatter.before({
  "duration": 2667236400,
  "status": "passed"
});
formatter.scenario({
  "line": 54,
  "name": "select the Category",
  "description": "",
  "id": "recipe;select-the-category",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 55,
  "name": "user is on the Recipe_class_registration form",
  "keyword": "Given "
});
formatter.step({
  "line": 56,
  "name": "select the category as \u0027Non-Veg\u0027",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_Recipe_class_registration_form()"
});
formatter.result({
  "duration": 1473244400,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.select_the_category_as_Non_Veg()"
});
formatter.result({
  "duration": 456621800,
  "status": "passed"
});
formatter.after({
  "duration": 868861500,
  "status": "passed"
});
formatter.before({
  "duration": 2773682900,
  "status": "passed"
});
formatter.scenario({
  "line": 59,
  "name": "select the City",
  "description": "",
  "id": "recipe;select-the-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 60,
  "name": "user is on the Recipe_class_registration form",
  "keyword": "Given "
});
formatter.step({
  "line": 61,
  "name": "select the city category as \u0027Mumbai\u0027",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_Recipe_class_registration_form()"
});
formatter.result({
  "duration": 1885386200,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.select_the_city_category_as_Mumbai()"
});
formatter.result({
  "duration": 556053600,
  "status": "passed"
});
formatter.after({
  "duration": 1007496100,
  "status": "passed"
});
formatter.before({
  "duration": 2237359100,
  "status": "passed"
});
formatter.scenario({
  "line": 64,
  "name": "select the Mode of Learning*",
  "description": "",
  "id": "recipe;select-the-mode-of-learning*",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 65,
  "name": "user is on the Recipe_class_registration form",
  "keyword": "Given "
});
formatter.step({
  "line": 66,
  "name": "select the mode as \u0027In house training\u0027",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_Recipe_class_registration_form()"
});
formatter.result({
  "duration": 146396100,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.select_the_mode_as_In_house_training()"
});
formatter.result({
  "duration": 695599800,
  "status": "passed"
});
formatter.after({
  "duration": 1886574500,
  "status": "passed"
});
formatter.before({
  "duration": 2778247100,
  "status": "passed"
});
formatter.scenario({
  "line": 68,
  "name": "select the Interested Course duration*",
  "description": "",
  "id": "recipe;select-the-interested-course-duration*",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 69,
  "name": "user is on the Recipe_class_registration form",
  "keyword": "Given "
});
formatter.step({
  "line": 70,
  "name": "select the duration as \u00276 months\u0027",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_Recipe_class_registration_form()"
});
formatter.result({
  "duration": 203197700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "6",
      "offset": 24
    }
  ],
  "location": "StepDefinition.select_the_duration_as_months(int)"
});
formatter.result({
  "duration": 689807600,
  "status": "passed"
});
formatter.after({
  "duration": 838769200,
  "status": "passed"
});
formatter.before({
  "duration": 1985464200,
  "status": "passed"
});
formatter.scenario({
  "line": 72,
  "name": "in the Enquire Now",
  "description": "",
  "id": "recipe;in-the-enquire-now",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 73,
  "name": "user is on the Recipe_class_registration form",
  "keyword": "Given "
});
formatter.step({
  "line": 74,
  "name": "click the \u0027Enquire Now\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 75,
  "name": "is displays Enquiry \u0027details must be filled out\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_Recipe_class_registration_form()"
});
formatter.result({
  "duration": 162613100,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.click_the_Enquire_Now()"
});
formatter.result({
  "duration": 134026900,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.is_displays_Enquiry_details_must_be_filled_out()"
});
formatter.result({
  "duration": 13449000,
  "status": "passed"
});
formatter.after({
  "duration": 930643300,
  "status": "passed"
});
formatter.before({
  "duration": 1996568000,
  "status": "passed"
});
formatter.scenario({
  "line": 78,
  "name": "in the Enquire details",
  "description": "",
  "id": "recipe;in-the-enquire-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 79,
  "name": "user is on the Recipe_class_registration form",
  "keyword": "Given "
});
formatter.step({
  "line": 80,
  "name": "user inputs  the details",
  "keyword": "When "
});
formatter.step({
  "line": 81,
  "name": "click the Enquire Now1",
  "keyword": "Then "
});
formatter.step({
  "line": 82,
  "name": "it displays\u0027Our location representative will contact you soon.\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinition.user_is_on_the_Recipe_class_registration_form()"
});
formatter.result({
  "duration": 166628600,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.user_inputs_the_details()"
});
formatter.result({
  "duration": 778750000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 21
    }
  ],
  "location": "StepDefinition.click_the_Enquire_Now(int)"
});
formatter.result({
  "duration": 1012032800,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinition.it_displays_Our_location_representative_will_contact_you_soon()"
});
formatter.result({
  "duration": 31676900,
  "status": "passed"
});
formatter.after({
  "duration": 852805300,
  "status": "passed"
});
});