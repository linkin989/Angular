package nifas;
import java.util.Scanner;
public class alph {

   public static void main(String args[])
   {
	   alph a=new alph();
	   String s=new String();
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Enter a string: ");
	  Scanner z=sc;
     
   }
}