package nifas;

class Inheritance4 {
	void k() {
		System.out.println("inheritance k");
	}
}

class Inheritance5 extends Inheritance4 {
	void k1() {
		int a = 4;
		int b = 5;
		System.out.println(a + b);
	}
}

 class Inheritance6 extends Inheritance5 {
	void k2()
	{ 
		int w=87;
		int t=54;
		System.out.println(w-t);
	}
 

	public static void main(String args[]) {
		Inheritance6 p  = new Inheritance6();
		p.k();
		p.k1();
		p.k2();
		System.out.println("hi");
	}
	}
