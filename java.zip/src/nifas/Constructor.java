package nifas;

public class Constructor {
	public Constructor() 
	{
		System.out.println("default constructor");
	}
    public Constructor(String name)
    {
    	System.out.println("string param ");
    }
    public Constructor(int a,int b) 
    {
    	System.out.println("int param");
    }
    
    void m1()
    {
    	System.out.println("method");
    }
    public static void main(String[] args)
    {
    	 Constructor t=new  Constructor("queue");
    	 Constructor t1=new  Constructor("2,3");
    	 Constructor t2=new  Constructor();
    	 t.m1();
    	 t1.m1();
    	 t2.m1();
    	 
    }
    
}
