package nifas;

 class ParseInput {
	public static void main(String arg[]) 
	{
		int a=Integer.parseInt(arg[0]) ;
		int b=Integer.parseInt(arg[1]) ;
		System.out.println( a + b );
	}
}
