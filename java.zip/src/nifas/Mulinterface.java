/*package nifas;

interface linkin {
	abstract void z();

	abstract void z1();
}

interface Mulinterface1 extends linkin {
	abstract void z25();

	abstract void z31();
}

interface Mulinterface extends Mulinterface1 {
	default void z() {
		// TODO Auto-generated method stub
		System.out.println("gdgdg");
	}

	void z1();

	void z25();

	static void z3() {
		System.out.println("gs");
	}

	public static void main(String args[]) {
		Mulinterface t = new Mulinterface();
		t.z();
		t.z1();
		t.z25();
	}

}*/