package nifas;

class Inheritance9 {
	void k()
	{
		System.out.println("inheritance");
	}
}
	class Inheritance1 extends Inheritance9 
	{
	 void k1()
    {
      int a=4;
      int b=5;
      System.out.println(a+b);
    }
	}
      public class Inheritance extends Inheritance1
      {
    	  
    
    public static void main(String args[]) {
    	Inheritance u= new Inheritance();
    	u.k();
    	u.k1();
    	u.m1();
    	
    }

	public void m1() {
		//* TODO Auto-generated method stub
		System.out.println("vfsdghfvh");
	}
    
    
			
			
			
}