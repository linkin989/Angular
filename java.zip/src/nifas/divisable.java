package nifas;

import java.util.Scanner;

public class  divisable{
	 public static void main(String[]args)
	 {
		 Scanner sc= new Scanner(System.in);
		 System.out.println("enter the first number");
		 int fnum=sc.nextInt();
		 System.out.println("enter the second number");
		 int pnum=sc.nextInt();
		 try{
		 int division=fnum/pnum;
		 System.out.println("division of two numbers" +division);
		 }
		 catch(Exception ae)
		 {
			 System.out.println("don't enter zero otherwise i call muthu!");
		 }
		
		 
	 }
}
