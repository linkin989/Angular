package nifas;

public class Jaga {
      static void add()
      {
    	  System.out.println("poda panni");
      }
      static void add(int a,int b)
      {
           System.out.println("additionm of two(int) is: "+(a+b));
      }
      static void sub(int a,int b)
      {
    	  System.out.println("subraction of two(int) is "+(a-b));
      }  
	     public static void main(String args[])
	     {
	    	 Jaga b=new Jaga();
	    	 b.add();
	    	 b.add(20,15);
	    	 b.sub(50,20);
	     }
}