/*package nifas;

class person {
	person(int a, int b) {
		this();
		System.out.println("person class constructor");
	}
}

class student extends person {
	student() {
		// super();
		System.out.println("dffdrd");
	}

}

class Superclass {
	public static void main(String[] args) {
		person a = new person();
	}
}*/