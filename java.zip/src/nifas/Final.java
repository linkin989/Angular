package nifas;

 class Came  {
  int a=141;
       public void add() {
    	a=++a;
    	int b=6;
    	System.out.println(a+b);  			
    }
}
 public class Final extends Came {
	   public void sub() {
		  a=--a;
		  int b=5;
		  System.out.println(a+b);
	  }
   public static void main(String args[]) {
		   Final q= new Final();
		   q.add();
		   
	  }
 }