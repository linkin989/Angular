package nifas;

import java.io.InputStream;

public class Scanner {

	public Scanner(InputStream in) {
		// TODO Auto-generated constructor stub
	}

	public int nextInt() {
		// TODO Auto-generated method stub
		return 0;
	}

}
