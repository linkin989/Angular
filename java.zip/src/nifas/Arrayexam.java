/*package nifas;

import java.util.Scanner;

public class Arrayexam {
	public int sum13(int[] nums) {
		int sum = 0;
		for (int i = 0; i < nums.length; i++) {
			if (nums[i] == 13) {
				i++;
				continue;
			} else {
				sum = sum + nums[i];
			}
		}
		System.out.println(sum);
		return sum;

	}

public static void main(String args[])
{
	 Arrayexam a=new Arrayexam();
	 Scanner sc= new Scanner(System.in);
	 System.out.println("enter the first number");
	 int nums=sc.nextInt();
	 a.sum13(nums);
}
}
*/