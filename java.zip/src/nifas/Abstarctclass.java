package nifas;
abstract class loop {
	void k()
	{
		System.out.println("inheritnce");
	}
	abstract void m1();
}
 class  goop extends loop {
 void k1()
 {
   int a=4;
   int b=5;
   System.out.println(a+b);
 }   

@Override
void m1() {
	// TODO Auto-generated method stub
	System.out.println("dae");
	
}
	}
 public class Abstarctclass extends goop
 {
	 public static void main(String args[]) {
	    	Inheritance t= new Inheritance();
	    	t.k();
	    	t.k1();
	    	t.m1();
 }
 }