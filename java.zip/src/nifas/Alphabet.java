package nifas;

public class Alphabet{

    public static void main(String args[]) {

    	 printAlphabetsInUpperCase();
    }

   

    public static void printAlphabetsInUpperCase() {
        System.out.println("\nList of alphabets in upper case :");
        for (char ch = 'A'; ch <= 'Z'; ch++) {
            System.out.printf("%s ", ch);
        }
    }

}
