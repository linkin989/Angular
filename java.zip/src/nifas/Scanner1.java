package nifas;

import java.util.Scanner;

public class Scanner1
{
	public static void main(String args[])
	{
		Scanner emp=new Scanner(System.in);
		System.out.println("Enter employee name");
		String name=emp.next();
		name=emp.nextLine();
		System.out.println("Enter id number of the employee");
		int b=emp.nextInt();
		System.out.println("Enter salary  of the employee");
		int c=emp.nextInt();
		System.out.println("enter the company ");
		String company=emp.next();
		company=emp.nextLine();
	}
	
	
}
 