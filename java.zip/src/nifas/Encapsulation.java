package nifas;
class Encapsulation {
	 public static void main(String[]args)
	 {
		 employee r=new employee();
		 r.setEid(25);
		 r.setEname("nifas");
		 r.setAtmpin(454545);
		 System.out.println( r.getEid( ));
		 System.out.println( r.getEname( ));
		 System.out.println( r.getAtmpin( ));
	 }

}
 