package nifas;

	class Inheritabala {
		void k() {
			System.out.println("inheritance k");
		}
	}

	class Inheritancechandru extends Inheritabala {
		void k1() {
			int a = 4;
			int b = 5;
			System.out.println(a + b);
		}
	}
	 public class hierarchy9 extends Inheritance{
		 
	 public static void main(String args[])
	 {
		 hierarchy9 r=new hierarchy9();
		 r.k1();                                                                                                                                                                                                                                                                                                                                                                                                                                                            
		 Inheritabala o=new Inheritabala();
		 o.k();
		 
	 }
	 
}
