package nifas;

 class Exception8 extends Exception {
	 
	 public Exception8(String errorMsg)
	 {
		    super(errorMsg);
	 }
     }
 public  class Exception5
 {
	 static void validation(int age) throws Exception8
	 {
		 if(age<18)
		 {
			 throw new Exception8("your not eligable");
		 }
		     else
		     {
		    	 System.out.println("your eligable");
		     }
	 }
	 public static void main(String[] args) throws Exception8
	 {
		 Exception5.validation (16);
		 System.out.println("rest of code.......!");
	 }
 }