/*
public class Multry {
                try{
                	System.out.println("division");
                	int b=30/2;
                	
                }catch(ArithmeticException e1)
                {
                System.out.println(e1);
                   }
                try{
                	int a[]=new int[3];
                	a[3]=4;
                }catch(ArrayIndexOutOfBoundsException e) {
                	System.out.println(e1);
                	
                }
          }

}*/