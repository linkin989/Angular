package com.cap.core;

public class exception {
	public static void main(String[]args)
	{
		try{
			int a[]=new int[5];
			a[4]=30/2;
			String s= "nifa";
			int r= Integer.parseInt(s);
			System.out.println(s.length());
			System.out.println("no error"+a[4]+" "+r);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("pleaseenter the number");
		}
		catch(ArithmeticException e) {
			System.out.println("don't enter zero");
		}
		catch(NumberFormatException e) {
			System.out.println("we can't convert");
		}
		catch(Exception e) {
			System.out.println("unable to find length");
		}			
	finally {
	      System.out.println("executes");
	}
	System.out.println("remaining codes..! ");
	}
}


