import java.util.Comparator;
import java.util.TreeSet;
class Employee1 
{
 
    String name;//
    int eid;//100
    int esal;
    Employee1(String name,int eid,int esal){
        this.name=name;
        this.eid=eid;
        this.esal=esal;
    }
	@Override
	public String toString() {
		return "Employee1 [name=" + name + ", eid=" + eid + ", esal=" + esal + "]";
	}
    
    }