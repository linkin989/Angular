import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes}  from '@angular/router';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { ListemployeeComponent } from './listemployee/listemployee.component';
const routes: Routes=[
  {
    
    path:'Employee-List',
    component:AddemployeeComponent
    
    },
    {
    path:'Display-List',
    component:ListemployeeComponent
    
    }
   ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports:[RouterModule]
})
export class AppRoutingModule { }
