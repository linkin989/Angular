import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-emp',
  templateUrl: './list-emp.component.html',
  styleUrls: ['./list-emp.component.css']
})
export class ListEmpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
