import { Component, OnInit } from '@angular/core';
import { Employee, MyserviceService } from '../myservice.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {
createdEmployee:Employee;
CreatedFlag:boolean=false;
service:MyserviceService;
  constructor(service:MyserviceService,public router:Router) {this.service=service}

  ngOnInit() {
  }
  add(data:any){
    this.router.navigateByUrl('Display-List');
    this.createdEmployee=new Employee(data.id,data.name);
    this.service.add(this.createdEmployee);
    }
}
