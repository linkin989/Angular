import { Component, OnInit } from '@angular/core';
import { MyserviceService,Employee} from '../myservice.service';
import { setRootDomAdapter } from '../../../node_modules/@angular/platform-browser/src/dom/dom_adapter';

@Component({
  selector: 'app-listemployee',
  templateUrl: './listemployee.component.html',
  styleUrls: ['./listemployee.component.css']
})
export class ListemployeeComponent implements OnInit {
service:MyserviceService;
constructor(service:MyserviceService)
{
  this.service=service;
}
 employees:Employee[]=[]

  ngOnInit() {
    this.service.fetchEmployees();
    this.employees=this.service.getemployees();
  }
  delete(id:number)
  {
  this.service.delete(id);
  }

column:string="id";
order:boolean=true;
sort(column:string){
if(this.column==column)
 {
this.order=!this.order;
 }else{
this.order=true;
this.column=column;
 }
}
}