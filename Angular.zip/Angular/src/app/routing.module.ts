import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule,Routes} from '@angular/router';
import { AddEmpComponent } from './add-emp/add-emp.component';
import { ListEmpComponent } from './list-emp/list-emp.component';


const routes: Routes=[
 {
 path:'Employee-List',
 component:AddEmpComponent
 
 },
 {
 path:'Display-List',
 component:ListEmpComponent
 
 }
];
 
@NgModule({
 imports: [RouterModule.forRoot(routes)],
 
 exports:[RouterModule],
 declarations: []
})
export class AppRoutingModule { }