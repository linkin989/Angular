package com.cap.dao;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCase {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
