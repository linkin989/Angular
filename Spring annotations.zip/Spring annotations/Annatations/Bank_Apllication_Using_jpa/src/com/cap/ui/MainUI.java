package com.cap.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cap.bean.Account;
import com.cap.bean.Transaction;
import com.cap.service.BankService;
import com.cap.service.BankServiceImpl;

public class MainUI {
	static BankService service = new BankServiceImpl();
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		while (true) {
			 //menus
			System.out.println("welcome to bank application");
			System.out.println("1.create Account");
			System.out.println("2.show balance");
			System.out.println("3.deposit");
			System.out.println("4.withdraw");
			System.out.println("5.fund Transfer");
			System.out.println("6.print Transaction");
			int choose = scanner.nextInt();
			switch (choose) {
			//creating cases
			//customer name
			//customer phone number
			//customer account type
			//validation
			case 1:
				   
				String cusname;
				boolean nameValid = false;
				do {
					System.out.println("Enter Your Name :");
					cusname = scanner.next();
					nameValid = service.nameValidation(cusname);
					if (!nameValid) {
						System.out.println("Alphabets only eg: Sama");
					}
				} while (!nameValid);

				long cusphone;
				boolean numberValid = false;
				do {
					System.out.println("Enter Your phone :");
					cusphone = scanner.nextLong();
					numberValid = service.numberValid(cusphone);
					if (!numberValid) {
						System.out.println("PhoneNumbers only eg: 8428818533");
					}
				} while (!numberValid);

				String cusacctype;
				boolean accTypevalid = false;
				do {
					System.out.println("Enter Your accType :");
					cusacctype = scanner.next();                                            //we created validation 
					                                                                        //for only name,phone num,acctype
					accTypevalid = service.accTypevalid(cusacctype);
					if (!accTypevalid) {
						System.out.println("accountType only in savings or current");
					}
				} while (!accTypevalid);

				System.out.println("Enter your Balance :");
				int cusbalance = scanner.nextInt();
				System.out.println("Enter Your Branch :");
				String cusbranch = scanner.next();
				Account account = new Account();
				account.setName(cusname);
				account.setPhoneNo(cusphone);
				account.setBalance(cusbalance);
				account.setAccType(cusacctype);
				account.setBalance(cusbalance);
				account.setBranch(cusbranch);

				long accountNum = service.createAccount(account);

				System.out.println("********************");
				System.out.println("Account created with :" + accountNum);
				System.out.println("********************");
				break;
			case 2:
				// showing the current balance of the customer and checking whether the acoount is exists
				try {
					System.out.println("show balance");
					System.out.println("Enter Your AccountNum :");
					long accountNum2 = scanner.nextLong();
					long bal = service.showBalance(accountNum2);
					System.out.println("You balance is:" + bal);

				} catch (Exception e) {
					System.out.println("Enter your valid Account Number ");
				}
				break;
			case 3:
				  //user inserting the amount from the  user and display the  updated balance
				try {
					System.out.println("deposit");
					System.out.println("Enter Your AccountNum :");
					long accountNum3 = scanner.nextLong();
					System.out.println("Enter your Amount :");
					int newBal = scanner.nextInt();
					long updatedbal = service.depositAmount(accountNum3, newBal);
					System.out.println("You new  balance is:" + updatedbal);
				} catch (Exception e) {
					System.out.println("Enter your valid Account Number ");
				}

				break;
			case 4:
				  //user withdraw the amount
				try {
					System.out.println("withdraw");
					System.out.println("Enter Your AccountNum :");
					long accountNum4 = scanner.nextLong();
					System.out.println("Enter your Amount :");
					int newBal1 = scanner.nextInt();
					long updatedbal1 = service.withdrawAmount(accountNum4, newBal1);
					System.out.println("Your withdraw amount is:" + updatedbal1);
				} catch (Exception e) {
					System.out.println("Enter your valid Account Number ");
				}

				break;

			case 5:
				// user transfering the amount to another user
				try {
					System.out.println("******Fund Transfer******");
					System.out.println("Enter your Account Number: ");
					long accountNum5 = scanner.nextLong();
					System.out.println("Enter the Account Number of the person whom you want to tranfer money to: ");
					long accountNum6 = scanner.nextLong();
					System.out.println("Enter the Amount, How much you want to transfer: ");
					int fundTrans = scanner.nextInt();
					long funTrans1 = service.fundTransfer(accountNum5, accountNum6, fundTrans);
					System.out.println("Your Balance after transferring amount is: " + funTrans1);
					System.out.println("Thank you for service");
				} catch (Exception e) {
					System.out.println("Enter your valid Account Number ");
				}
				break;
			case 6:
				//it shows the all transcation
				System.out.println("Showing all the Transaction");
			     service.getTranscation();

		     
		       	break;
			

			case 7:
				System.out.println("Thank you");
				System.exit(0);
			}
		}
	}
}
