package com.cap.Exception;

@SuppressWarnings("serial")
public class AccountNotFoundException extends RuntimeException {
	public AccountNotFoundException(final String message) {
		super(message);

	}
}
