package com.cap.service;

import java.util.List;

import com.cap.bean.Account;
import com.cap.bean.Transaction;

public interface BankService {
    // here also same as dao interface
	long createAccount(Account account);

	long showBalance(long accountNum2);

	long depositAmount(long accountNum2, int newBal);

	long withdrawAmount(long accountNum3, int newBal1);

	long fundTransfer(long accountNum5, long accountNum6, long fundTrans);

     void getTranscation();
     
	boolean nameValidation(String cusName);

	boolean numberValid(long cusphone);

	boolean accTypevalid(String cusacctype);



}
