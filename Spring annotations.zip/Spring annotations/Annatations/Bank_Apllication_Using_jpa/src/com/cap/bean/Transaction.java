package com.cap.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name="tra")
public class Transaction {
	@Id
	@GeneratedValue
	@Column(length=10)
	private long tid;
	@Column(length=10)
	private long fromAccount;
	@Column(length=10)
	private long toaccount;
	@Column(length=10)
	private long oldBalance;
	@Column(length=10)
	private long newBalance;
	@Column(length=10)
	private String transcationType;

	public long getTid() {
		return tid;
	}

	public void setTid(long tid) {
		this.tid = tid;
	}

	public long getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(long fromAccount) {
		this.fromAccount = fromAccount;
	}

	public long getToaccount() {
		return toaccount;
	}

	public void setToaccount(long toaccount) {
		this.toaccount = toaccount;
	}

	public long getOldBalance() {
		return oldBalance;
	}

	public void setOldBalance(long oldbalance2) {
		this.oldBalance = oldbalance2;
	}

	public long getNewBalance() {
		return newBalance;
	}

	public void setNewBalance(long newBalance2) {
		this.newBalance = newBalance2;
	}

	public String getTranscationType() {
		return transcationType;
	}

	public void setTranscationType(String transcationType) {
		this.transcationType = transcationType;
	}

	@Override
	public String toString() {
		return "Transcation [tid=" + tid + ", fromAccount=" + fromAccount + ", toaccount=" + toaccount + ", oldBalance="
				+ oldBalance + ", newBalance=" + newBalance + ", transcationType=" + transcationType + "]";
	}

	

}
