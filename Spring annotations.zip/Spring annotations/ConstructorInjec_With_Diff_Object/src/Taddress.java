
public class Taddress {
	private int houseno;
	private String colony;
	private String city;
	public int getHouseno() {
		return houseno;
	}
	public void setHouseno(int houseno) {
		this.houseno = houseno;
	}
	public String getColony() {
		return colony;
	}
	public void setColony(String colony) {
		this.colony = colony;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Address [houseno=" + houseno + ", colony=" + colony + ", city=" + city + "]";
	}
	public Taddress(int houseno, String colony, String city) {
		super();
		this.houseno = houseno;
		this.colony = colony;
		this.city = city;
	}
	public Taddress() {
		super();
	}
	
	
	
	
	
	
	
	

}
