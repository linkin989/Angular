
public class Employee {
	private int id;
	private String name;
	private int sal;
	
	private Address p;
	
	private Taddress hhh;
	
	public Taddress getHhh() {
		return hhh;
	}
	public void setHhh(Taddress hhh) {
		this.hhh = hhh;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	void display(){
		 System.out.println(getId());
		 System.out.println(getName());
		 System.out.println(getSal());
		 System.out.println(p);
		 System.out.println(hhh);
	}
	
	
	
	
	
	
	
	
	
	public Address getP() {
		return p;
	}
	public void setP(Address p) {
		this.p = p;
	}
	public Employee(int id, String name, int sal, Address p, Taddress hhh) {
		super();
		this.id = id;
		this.name = name;
		this.sal = sal;
		this.p = p;
		this.hhh = hhh;
	}
	public Employee() {
		super();
	}
	
	
	
	
	
	
	
	
	 
}
