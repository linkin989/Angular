package com.cg.jpacrud.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.jpacrud.dao.EmployeeDao;
import com.cg.jpacrud.dao.EmployeeDaoImpl;
import com.cg.jpacrud.entities.Employee;

@Service("service")
public class EmployeeServiceImpl implements EmployeeService {
    
	private EmployeeDao dao;
	@Autowired
	public void setEmployeedao(EmployeeDao employeedao) {
		this.dao = employeedao;
	}

	@Override
	
	public void CreateEmployee(Employee employee) {
		
	    dao.CreateEmployee(employee);
		
		
		
	}

	@Override
	public Employee  findEmployee(int empId) {
		Employee empl=dao.findEmployee(empId);
	return empl;
	}
	@Override
	public void  UpdateEmployee(Employee emp) {
		
		dao.UpdateEmployee(emp);
		
   
	}

	@Override
	public void delete(Employee e3) {
		
		dao.delete(e3);
		
		
		
	}

	@Override
	public List<Employee> ListTransaction() {
		List<Employee> l1=dao.ListTransaction();
		return l1;
	}

	
	
	
	

}

