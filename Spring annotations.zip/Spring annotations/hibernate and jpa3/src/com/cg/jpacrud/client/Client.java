package com.cg.jpacrud.client;

import java.util.List;
import java.util.Scanner;

import javax.persistence.TypedQuery;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.jpacrud.entities.Employee;
import com.cg.jpacrud.service.EmployeeService;
import com.cg.jpacrud.service.EmployeeServiceImpl;

public class Client {
	static Scanner scanner=new Scanner(System.in);

	public static void main(String[] args) {
		ApplicationContext txt= new ClassPathXmlApplicationContext("Bean.xml");
		EmployeeService service= txt.getBean("service",EmployeeServiceImpl.class);
		 Scanner sc=new Scanner(System.in);

		while (true) {
			// menus
			System.out.println("welcome to Employee Application");
			System.out.println("1.create employee");
			System.out.println("2.add employee");
			System.out.println("3.update employee");
			System.out.println("4.delete employee");
			System.out.println("5.list all transcation");
			int choose = scanner.nextInt();
			switch (choose) {
			case 1:
				Employee emp = new Employee();
				System.out.println("Enter your name ");
				String empname = scanner.next();
				System.out.println("enter the address");
				String empaddress = scanner.next();
				emp.setName(empname);
				//emp.setId(empid);
				emp.setAddress(empaddress);
				service.CreateEmployee(emp);
				System.out.println(emp.getId());
				break;

			case 2:
				System.out.println("Enter the Employee id");
				int empid1 = scanner.nextInt();
				Employee e = service.findEmployee(empid1);
				System.out.println("Id= " + e.getId()+" Name:"+e.getName()+" Address:"+e.getAddress());
				break;

			case 3:
				Employee e1=new Employee();
				System.out.println("Enter the Employee id");
				int empid2 = scanner.nextInt();
				e1 = service.findEmployee(empid2);
				System.out.println("update Name");
				String empName1 = scanner.next();
				e1.setName(empName1);
				service.UpdateEmployee(e1);
				System.out.println(e1.getName());
				break;
			case 4:                               
				System.out.println("Enter the Employee id");
			    int empId3=scanner.nextInt();
			    Employee e3=service.findEmployee(empId3);
			    service.delete(e3);
			    System.out.println("Sucessfully deleted");
			    break;
			case 5:
				  List<Employee> l1= service.ListTransaction();
			       for(Employee e4:l1)
			        {
			            System.out.println(e4.getId());
			            System.out.println(e4.getName());
			            System.out.println(e4.getAddress());
			          
			        }
				
				

			}

		}

	}
}