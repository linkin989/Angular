package com.cg.jpacrud.service;

import java.util.List;

import com.cg.jpacrud.entities.Employee;

public interface EmployeeService {
	
	public abstract void CreateEmployee(Employee employee);


	public abstract  Employee findEmployee(int empId);

	public void UpdateEmployee(Employee emp);

	public void delete(Employee e3);

	public List<Employee> ListTransaction();
		
	

}
