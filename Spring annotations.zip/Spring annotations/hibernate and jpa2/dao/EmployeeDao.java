package com.cg.jpacrud.dao;



import java.util.List;

import com.cg.jpacrud.entities.Employee;

public interface EmployeeDao {
	
	public abstract void CreateEmployee(Employee employee);

	
	

	public  void  UpdateEmployee(Employee emp);

	public abstract Employee findEmployee(int id);

	public  void delete(Employee e3);
	
	public List<Employee> ListTransaction();

}
