
package com.cg.jpacrud.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.jpacrud.entities.Employee;
@Repository
@Transactional
public class EmployeeDaoImpl  implements EmployeeDao {
	
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	@Override
	
	public void CreateEmployee(Employee employee) {
		entityManager.persist(employee);
		
	}
	
	@Override
	
	public Employee findEmployee(int id) {
		Employee e=entityManager.find(Employee.class,id);
		return e;
	}
	
	
	
	@Override
	public void UpdateEmployee(Employee emp) {
		entityManager.merge(emp);
		
	}
	@Override
	public void delete(Employee e3) {
		entityManager.remove(e3);
		
	}
	@Override
	public List<Employee> ListTransaction() {
		TypedQuery<Employee> q2=entityManager.createQuery("select c from Employee c",Employee.class);
	    List<Employee> l1=q2.getResultList();
		return l1;
	}

	
	
	
	
	
	
}