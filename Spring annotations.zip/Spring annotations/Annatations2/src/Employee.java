import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
	private int id;
	private String name;
	private int sal;
	
	private Address p;
	

	
	@Autowired
	public Employee(int id, String name, int sal, Address p) {
		super();
		this.id = id;
		this.name = name;
		this.sal = sal;
		this.p = p;
	}
	void display(){
		System.out.println(id);
		System.out.println(name);
		System.out.println(sal);
		System.out.println(p);
	}
}
	