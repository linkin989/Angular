function add(x, y) {
    return x + y;
}
//anonymous function with number as return type
var sum = function (x, y) {
    return x + y;
};
add(14, 15);
sum(12, 13);
var sum1 = function (x, y) { return x + y; };
sum1(123, 234);
var sum2 = function (x, y) { return x + y; };
sum2(123, 234);
var sum3 = function (x, y) { return x + y; };
sum3(123, 234);
var sum4 = function () { return console.log("function with out return"); };
sum4();
