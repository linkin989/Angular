export class person{
     firstname: string;
     lastname: string;
    constructor(firstname:string,lastname:string)
    {
        this.firstname=firstname;
        this.lastname=lastname;
    }
   fullName():string
    {
      return this.firstname +"  "+this.lastname;
    }
}



   

export class nif extends person
{
id:number;
constructor( _id:number,_firstname:string,_lastname:string)
{
    super(_firstname,_lastname);
    this.id=_id;
}
showDetails(): void {
    console.log(this.id+":"+this.fullName());
}
}
let e1=new nif(1,"rajesh","kumar");
e1.showDetails();