var person = /** @class */ (function () {
    function person() {
    }
    return person;
}());
var o = new person();
o.firstname = "suresh";
o.lastname = "kumar";
console.log(o.firstname + "" + o.lastname);
