class employee
{
    static empid:number;
    name:string;
    constructor(empid:number,name:string)
    {
        employee.empid=empid;
        this.name=name;
    }
      displayDetails(){
          return employee.empid+"    "+this.name;

      }
    }
             var emp=new employee(123,"nifas");
             console.log(emp.displayDetails());

  