var firstname = "international";
var site = "www.ibm.com";
var str = "hello my name is " + firstname + "and my site" + site;
console.log(str);
var str2 = "hello my name is  " + firstname + " and  my site is " + site;
console.log(str2);
