class person
{
    firstname:string;
    lastname:string;

}
   var o=new person();
   o.firstname="suresh";
   o.lastname="kumar";

   console.log(o.firstname+""+o.lastname)