function add(x:number,...y:number[]):number{
    let result=x;
    for(var i=0;i<y.length;i++)
    {
        result +=y[i];
    }
    return result;

}
let re=add(4,3);
let ret=add(4,3,2);
console.log(re);
console.log(ret);
