function add(x, y, z) {
    var result;
    if (typeof x == "number" && typeof y == "number" && typeof z == "number") {
        result = x + y + z;
    }
    else {
        result = x + y + " " + z;
    }
    return result;
}
var re = add(4, 3, 2);
var re2 = add("welcome", "hello", "hai");
console.log(re);
console.log(re2);
