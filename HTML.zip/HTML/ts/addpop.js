var n = 14;
var a1 = [1, 2, 3, "a", true];
var x;
x = [1, 2, 3, 4];
for (var i in x) {
    console.log(i);
}
x.push(10);
n = x.pop();
var numberList = [1, 2, 3];
var numList = [1, 2, 3];
