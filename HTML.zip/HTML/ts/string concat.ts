let firstname:string="international";
let site:string="www.ibm.com";
let str="hello my name is "+firstname+"and my site"+site;
console.log(str)

let str2=`hello my name is  ${firstname} and  my site is ${site}`;
console.log(str2)

