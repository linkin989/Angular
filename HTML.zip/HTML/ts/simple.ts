
var b="welcome";


var d:boolean=false;


var a:number=45;
var p:number=50;



var c:string;
c="hffh"
console.log(a+p);
console.log(c);
 
