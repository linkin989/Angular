var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var person = /** @class */ (function () {
    function person(firstname, lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }
    person.prototype.fullName = function () {
        return this.firstname + "  " + this.lastname;
    };
    return person;
}());
var nif = /** @class */ (function (_super) {
    __extends(nif, _super);
    function nif(_id, _firstname, _lastname) {
        var _this = _super.call(this, _firstname, _lastname) || this;
        _this.id = _id;
        return _this;
    }
    nif.prototype.showDetails = function () {
        console.log(this.id + ":" + this.fullName());
    };
    return nif;
}(person));
var e1 = new nif(1, "rajesh", "kumar");
e1.showDetails();
