function add(x:number,y:number):number
{
 return x+y;
}
//anonymous function with number as return type
let sum=function(x:number,y:number):number
{
 return x+y;
}
add(14,15);
sum(12,13);
 
let sum1=(x:number,y:number)=>x+y;
sum1(123,234);
 
let sum2=(x:number,y:number)=>{return x+y};
sum2(123,234);
 
let sum3=(x,y)=>x+y;
sum3(123,234);
 
let sum4=()=>console.log("function with out return");
sum4();