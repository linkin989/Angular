var b = "welcome";
var d = false;
var a = 45;
var p = 50;
var c;
c = "hffh";
console.log(a + p);
