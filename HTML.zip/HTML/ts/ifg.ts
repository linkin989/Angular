function f1()
{
    let a=55;
    if(a>50)
    {
        var b=23;
        console.log(a);
    }
    console.log(b);
}
f1()