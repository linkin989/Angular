var employee = /** @class */ (function () {
    function employee(empid, name) {
        employee.empid = empid;
        this.name = name;
    }
    employee.prototype.displayDetails = function () {
        return employee.empid + "    " + this.name;
    };
    return employee;
}());
var emp = new employee(123, "nifas");
console.log(emp.displayDetails());
