function add(t:number,u:number)
{
return t+u;
}
var sum=add(100,500);
console.log(sum);



var c:string;
c="gfddd"
function addition(t:number,u:number)
{
return t+u;
}
var sum1=addition(200,200);
console.log(sum1);



function add1(t,u,m?:number)
{
return t+u+m;
}
var sum3=add1(100,500);
console.log(sum3);



function add2(t,u,m:number)
{
return t+u+m;
}
var sum8=add2(100,500,500);
console.log(sum8);



function add5(t,u,m):number
{
return t+u+m;
}
var sum9=add5(100,500,800);
console.log(sum9);

