import {person,nif} from "./emplou";
let st =new nif(4,"kum","raj");
let result=st.showDetails();
console.log("")