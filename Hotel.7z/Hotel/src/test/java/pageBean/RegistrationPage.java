package pageBean;

import org.openqa.selenium.WebDriver;

public class RegistrationPage {
  
	
	WebDriver driver;
	
}
