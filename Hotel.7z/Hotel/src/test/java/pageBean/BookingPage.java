package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;



public class BookingPage {
	WebDriver driver;
	
	
	
	//firstName
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement firstName;
	
	
    //lastName
	@FindBy(xpath="//*[@id='txtLastName']")
	@CacheLookup
	WebElement lastName;
	
	//email 
	@FindBy(how=How.NAME, using="Email")
	@CacheLookup
	WebElement email;
	
	//mobile  number starts with 8 or 9
	@FindBy(id ="txtPhone")
	@CacheLookup
	WebElement mobileNo;
	
	@FindBy(how=How.NAME, using="persons")
	@CacheLookup
	int personCount;
	
	
    //city
	@FindBy( how=How.NAME, using="city")
	@CacheLookup
	WebElement city;
	
	//state
	@FindBy(how=How.NAME, using="state")
	@CacheLookup
	WebElement state;
	
	
	//cardholder name
	@FindBy(how=How.ID, using="txtCardholderName")
	@CacheLookup
	WebElement cardHolderName;
	
   //debitcard no
	@FindBy(id="txtDebit")
	@CacheLookup
	WebElement debitNo;
	
	//card cvv no
	@FindBy(id ="txtCvv")
	@CacheLookup
	WebElement cvv;
	
	//card expirymonth
	@FindBy(id="txtMonth")
	@CacheLookup
	WebElement expiryMonth;

	//card expiry year
	@FindBy(id="txtYear")
	@CacheLookup
	WebElement year;
	
	
	@FindBy(how=How.ID, using="btnPayment")
	@CacheLookup
	WebElement payment;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}


	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}
	
	public int getPersonCount() {
		return personCount;
	}
	public void setPersonCount(int personCount) {
		this.personCount=personCount;
	}
	
	
	

	public WebElement getCardHolderName() {
		return cardHolderName;
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}

	public WebElement getDebitNo() {
		return debitNo;
	}

	public void setDebitNo(String debitNo) {
		this.debitNo.sendKeys(debitNo);
	}

	public WebElement getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public WebElement getExpiryMonth() {
		return expiryMonth;
	}

	public void setExpiryMonth(String expiryMonth) {
		this.expiryMonth.sendKeys(expiryMonth);
	}

	public WebElement getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year.sendKeys(year);
		
	}

	public WebElement getPayment() {
		return payment;
	}

	public void setPayment() {
		this.payment.click();
	}

	
	
	public BookingPage(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	

}
