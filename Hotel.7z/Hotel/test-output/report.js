$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/nifasa/Desktop/Testing1/Hotel/src/test/resource/Booking/Booking.feature");
formatter.feature({
  "line": 1,
  "name": "HotelBooking",
  "description": "",
  "id": "hotelbooking",
  "keyword": "Feature"
});
formatter.before({
  "duration": 7069877600,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "Invalid first name",
  "description": "",
  "id": "hotelbooking;invalid-first-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "user enters invalid first name",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "displays \u0027Please fill the first Name\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 620487400,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_invalid_first_name()"
});
formatter.result({
  "duration": 140478100,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.displays_Please_fill_the_first_Name()"
});
formatter.result({
  "duration": 321435900,
  "status": "passed"
});
formatter.before({
  "duration": 2108009100,
  "status": "passed"
});
formatter.scenario({
  "line": 9,
  "name": "Invalid last name",
  "description": "",
  "id": "hotelbooking;invalid-last-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 10,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "user enters invalid last name",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "displays \u0027Please fill the Last Name\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 153026800,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_invalid_last_name()"
});
formatter.result({
  "duration": 278693000,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.displays_Please_fill_the_Last_Name()"
});
formatter.result({
  "duration": 364382600,
  "status": "passed"
});
formatter.before({
  "duration": 1922933100,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Invalid Email",
  "description": "",
  "id": "hotelbooking;invalid-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "user enters invalid email",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "display \u0027Please fill the Email\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 1595293900,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_invalid_email()"
});
formatter.result({
  "duration": 293427600,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.display_Please_fill_the_Email()"
});
formatter.result({
  "duration": 2099456900,
  "status": "passed"
});
formatter.before({
  "duration": 1467748100,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "Invalid Mobile Number",
  "description": "",
  "id": "hotelbooking;invalid-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 21,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 22,
  "name": "user enters invalid mobile number",
  "keyword": "When "
});
formatter.step({
  "line": 23,
  "name": "display \u0027Please fill Mobile No.\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 4239883200,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_invalid_mobile_number()"
});
formatter.result({
  "duration": 492830900,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.display_Please_fill_Mobile_No()"
});
formatter.result({
  "duration": 270612000,
  "status": "passed"
});
formatter.before({
  "duration": 1881637500,
  "status": "passed"
});
formatter.scenario({
  "line": 25,
  "name": "Wrong Mobile Number",
  "description": "",
  "id": "hotelbooking;wrong-mobile-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 26,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 27,
  "name": "user enters wrong mobile number",
  "keyword": "When "
});
formatter.step({
  "line": 28,
  "name": "display \u0027Please enter valid Mobile Number\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 3273181500,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_wrong_mobile_number()"
});
formatter.result({
  "duration": 413508900,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.display_Please_enter_valid_Mobile_Number()"
});
formatter.result({
  "duration": 2101179700,
  "status": "passed"
});
formatter.before({
  "duration": 1604589300,
  "status": "passed"
});
formatter.scenario({
  "line": 31,
  "name": "Invalid Number of People staying",
  "description": "",
  "id": "hotelbooking;invalid-number-of-people-staying",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 33,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 34,
  "name": "user enters invalid Number of People staying",
  "keyword": "When "
});
formatter.step({
  "line": 35,
  "name": "display \u0027Number of people staying\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 2823635200,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_invalid_Number_of_People_staying()"
});
formatter.result({
  "duration": 20700,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.display_Number_of_people_staying()"
});
formatter.result({
  "duration": 15000,
  "status": "passed"
});
formatter.before({
  "duration": 3964587000,
  "status": "passed"
});
formatter.scenario({
  "line": 37,
  "name": "Invalid Address",
  "description": "",
  "id": "hotelbooking;invalid-address",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 38,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 39,
  "name": "user does not enter address",
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "display \u0027Please Enter Address\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 3327784700,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_does_not_enter_address()"
});
formatter.result({
  "duration": 22900,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.display_Please_Enter_Address()"
});
formatter.result({
  "duration": 17900,
  "status": "passed"
});
formatter.before({
  "duration": 2819367800,
  "status": "passed"
});
formatter.scenario({
  "line": 42,
  "name": "Invalid City",
  "description": "",
  "id": "hotelbooking;invalid-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 44,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 45,
  "name": "user enters invalid City",
  "keyword": "When "
});
formatter.step({
  "line": 46,
  "name": "display \u0027Please fill City\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 5303139700,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_invalid_City()"
});
formatter.result({
  "duration": 567915100,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.display_Please_fill_City()"
});
formatter.result({
  "duration": 265076700,
  "status": "passed"
});
formatter.before({
  "duration": 2278192700,
  "status": "passed"
});
formatter.scenario({
  "line": 48,
  "name": "Invalid State",
  "description": "",
  "id": "hotelbooking;invalid-state",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 50,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 51,
  "name": "user enters invalid State",
  "keyword": "When "
});
formatter.step({
  "line": 52,
  "name": "display \u0027Please fill the State\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 3656184800,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_invalid_State()"
});
formatter.result({
  "duration": 570683900,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.display_Please_fill_the_State()"
});
formatter.result({
  "duration": 525340100,
  "status": "passed"
});
formatter.before({
  "duration": 1691859900,
  "status": "passed"
});
formatter.scenario({
  "line": 54,
  "name": "Invalid cardHolder name",
  "description": "",
  "id": "hotelbooking;invalid-cardholder-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 56,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 57,
  "name": "user enters invalid name",
  "keyword": "When "
});
formatter.step({
  "line": 58,
  "name": "displays \u0027Please fill the CardHolder Name\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 3702120100,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_invalid_name()"
});
formatter.result({
  "duration": 649428600,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.displays_Please_fill_the_CardHolder_Name()"
});
formatter.result({
  "duration": 407083400,
  "status": "passed"
});
formatter.before({
  "duration": 2458598800,
  "status": "passed"
});
formatter.scenario({
  "line": 60,
  "name": "Invalid Debit Card Number",
  "description": "",
  "id": "hotelbooking;invalid-debit-card-number",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 62,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 63,
  "name": "user enters invalid Debit Card Number",
  "keyword": "When "
});
formatter.step({
  "line": 64,
  "name": "displays \u0027Please fill Debit Card Number\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 250681000,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_invalid_Debit_Card_Number()"
});
formatter.result({
  "duration": 844343600,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.displays_Please_fill_Debit_Card_Number()"
});
formatter.result({
  "duration": 354876900,
  "status": "passed"
});
formatter.before({
  "duration": 2197930900,
  "status": "passed"
});
formatter.scenario({
  "line": 66,
  "name": "CVV Not entered",
  "description": "",
  "id": "hotelbooking;cvv-not-entered",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 67,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 68,
  "name": "user does not enter CVV value",
  "keyword": "When "
});
formatter.step({
  "line": 69,
  "name": "displays \u0027Please fill CVV number\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 322611300,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_does_not_enter_CVV_value()"
});
formatter.result({
  "duration": 2211949100,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.displays_Please_fill_CVV_number()"
});
formatter.result({
  "duration": 764024500,
  "status": "passed"
});
formatter.before({
  "duration": 2048754300,
  "status": "passed"
});
formatter.scenario({
  "line": 71,
  "name": "Invalid expiration month",
  "description": "",
  "id": "hotelbooking;invalid-expiration-month",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 73,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 74,
  "name": "user enters invalid expiration month",
  "keyword": "When "
});
formatter.step({
  "line": 75,
  "name": "displays \u0027Please fill expiration month\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 174226200,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_invalid_expiration_month()"
});
formatter.result({
  "duration": 1028477200,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.displays_Please_fill_expiration_month()"
});
formatter.result({
  "duration": 507936500,
  "status": "passed"
});
formatter.before({
  "duration": 2035870900,
  "status": "passed"
});
formatter.scenario({
  "line": 77,
  "name": "Invalid expiration year",
  "description": "",
  "id": "hotelbooking;invalid-expiration-year",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 79,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 80,
  "name": "user enters invalid expiration year",
  "keyword": "When "
});
formatter.step({
  "line": 81,
  "name": "displays \u0027Please fill expiration year\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 140548500,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_invalid_expiration_year()"
});
formatter.result({
  "duration": 932113900,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.displays_Please_fill_expiration_year()"
});
formatter.result({
  "duration": 467929300,
  "status": "passed"
});
formatter.before({
  "duration": 1700634400,
  "status": "passed"
});
formatter.scenario({
  "line": 83,
  "name": "Valid Booking details",
  "description": "",
  "id": "hotelbooking;valid-booking-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 85,
  "name": "user is on \u0027hotelBooking\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 86,
  "name": "user enters valid  payment details",
  "keyword": "When "
});
formatter.step({
  "line": 87,
  "name": "displays \u0027Booking Completed!!!\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "BookStepDefinition.user_is_on_hotelBooking_page()"
});
formatter.result({
  "duration": 4108032300,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.user_enters_valid_payment_details()"
});
formatter.result({
  "duration": 1559298400,
  "status": "passed"
});
formatter.match({
  "location": "BookStepDefinition.displays_Booking_Completed()"
});
formatter.result({
  "duration": 5512826200,
  "status": "passed"
});
});