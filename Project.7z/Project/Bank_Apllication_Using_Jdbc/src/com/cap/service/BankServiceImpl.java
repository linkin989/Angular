package com.cap.service;

import java.util.List;

import com.cap.bean.Account;
import com.cap.bean.Transcation;
import com.cap.dao.BankDao;
import com.cap.dao.BankDaoimpl;

public class BankServiceImpl implements BankService {
	BankDao dao = new BankDaoimpl();

	@Override
	public long createAccount(Account account) {
		Long accNum = dao.createAccount(account);
		return accNum;
	}

	@Override
	public long showBalance(long accountNum2) {
		return  dao.showBalance(accountNum2);

	}

	@Override
	public long depositAmount(long accountNum2, int amount) {
		long updatedbal = dao.depositAmount(accountNum2, amount);
		return updatedbal;
	}

	@Override
	public long withdrawAmount(long accountNum3, int newBal1) {
		long updatedbal1 = dao.withdrawAmount(accountNum3, newBal1);
		return updatedbal1;
	}

	@Override
	public long fundTransfer(long accountNum5, long accountNum6, int fundTrans) {
		long updatedbal2 = dao.fundtransfer(accountNum5, accountNum6, fundTrans);
		return updatedbal2;

	}

	@Override
	public void getTranscation() {
		// TODO Auto-generated method stub
		dao.getTranscation();
	}

	@Override
	      //validation logic for customer name
	public boolean nameValidation(String cusname) {
		if (cusname.matches("[A-Z][a-zA-Z]*"))
			return true;
		else
			return false;
	}

	@Override
	 //validation for customer phone numbers
	public boolean numberValid(long cusphone) {
		String num = Long.toString(cusphone);
		if (num.matches("[8-9][0-9]*"))
			return true;
		else
			return false;
	}

	@Override
	//validation for customer acctype here we declaring only two options savings and current 
	public boolean accTypevalid(String cusacctype) {
		if (cusacctype.equalsIgnoreCase("savings") || cusacctype.equalsIgnoreCase("current"))
			return true;
		else
			return false;

	}
}
