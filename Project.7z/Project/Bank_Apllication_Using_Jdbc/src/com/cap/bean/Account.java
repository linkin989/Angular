package com.cap.bean;
    
public class Account {
	private long accNum;
	private String name;
	private long phoneNo;
	private int balance;
	private String accType;
	private String branch;

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long cusnum) {
		this.accNum = cusnum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int cusbalance) {
		this.balance = cusbalance;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

  //creating string to string method
	public String toString() {
		return "Account [accNum=" + accNum + ", name=" + name + ", phoneNo=" + phoneNo + ", balance=" + balance
				+ ", accType=" + accType + ", branch=" + branch + "]";
	}

}
