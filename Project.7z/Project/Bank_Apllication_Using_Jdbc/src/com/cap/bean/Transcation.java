package com.cap.bean;

public class Transcation {
	private long tid;
	private long fromAccount;
	private long toaccount;
	private int oldBalance;
	private int newBalance;
	private String transcationType;

	public long getTid() {
		return tid;
	}

	public void setTid(long tid) {
		this.tid = tid;
	}

	public long getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(long fromAccount) {
		this.fromAccount = fromAccount;
	}

	public long getToaccount() {
		return toaccount;
	}

	public void setToaccount(long toaccount) {
		this.toaccount = toaccount;
	}

	public int getOldBalance() {
		return oldBalance;
	}

	public void setOldBalance(int oldBalance) {
		this.oldBalance = oldBalance;
	}

	public int getNewBalance() {
		return newBalance;
	}

	public void setNewBalance(int newBalance) {
		this.newBalance = newBalance;
	}

	public String getTranscationType() {
		return transcationType;
	}

	public void setTranscationType(String transcationType) {
		this.transcationType = transcationType;
	}

	@Override
	public String toString() {
		return "Transcation [tid=" + tid + ", fromAccount=" + fromAccount + ", toaccount=" + toaccount + ", oldBalance="
				+ oldBalance + ", newBalance=" + newBalance + ", transcationType=" + transcationType + "]";
	}

}
