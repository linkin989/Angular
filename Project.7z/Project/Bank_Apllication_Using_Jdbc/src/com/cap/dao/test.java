package com.cap.dao;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.cap.bean.Account;
import com.cap.dao.BankDaoimpl;

public class test {
	// positive response
	BankDaoimpl dao = new BankDaoimpl();

	@Test
	public void createAcc_1() {
		Account bank = new Account();
		bank.setBalance(555);
		bank.setAccNum(1010);
		bank.setAccType("savings");
		bank.setPhoneNo(9898998988l);
		bank.setName("qwerty");
		long AccNum = dao.createAccount(bank);

		Assert.assertEquals(1001, AccNum);

	}

	// negative response
	@Test
	public void createAcc_2() {
		Account bank = new Account();
		bank.setBalance(1234);
		bank.setAccNum(1010);
		bank.setAccType("savings");
		bank.setPhoneNo(9898998988l);
		bank.setName("qwerty");
		long AccNum = dao.createAccount(bank);

		Assert.assertEquals(1001, AccNum);

	}
}
