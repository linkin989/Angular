package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.cap.bean.Account;
import com.cap.bean.Transcation;

public class BankDaoimpl implements BankDao {

	@Override
	public long createAccount(Account acc) {
		Connection conn = DBconnect.getConnection();
		long accNum = 0;
		try {

			PreparedStatement stmt = conn.prepareStatement("insert into Account values(accseq.nextval,?,?,?,?,?)");

			stmt.setString(1, acc.getName());
			stmt.setLong(2, acc.getPhoneNo());
			stmt.setInt(3, acc.getBalance());
			stmt.setString(4, acc.getAccType());
			stmt.setString(5, acc.getBranch());
			int result1 = stmt.executeUpdate();
			if (result1 > 0) {
				PreparedStatement p = conn.prepareStatement("select accseq.currval from dual");
				ResultSet rs = p.executeQuery();
				rs.next();
				accNum = rs.getLong(1);
				System.out.println("registered successfully");

			} else {
				System.out.println("failed");
			}
		}

		catch (SQLException e) {
			System.out.println(e);
		}

		return accNum;
	}

	@Override
	public long showBalance(long accountNum2) {
		Connection conn = DBconnect.getConnection();
		long accNum = 0;
		try {
			PreparedStatement stmt = conn.prepareStatement("select balance from Account where accNum=?");
			stmt.setLong(1, accountNum2);
			ResultSet r = stmt.executeQuery();
			r.next();
			accNum = r.getLong(1);
		} catch (SQLException e) {
			System.out.println("invalid number");
		}

		return accNum;
	}

	@Override
	public long depositAmount(long accountNum2, int amount) {
		
		long deposit=0;
		int result=0;
		Connection conn = DBconnect.getConnection();
		PreparedStatement p;
		try{
			p=conn.prepareStatement("select balance from Account where accNum=?");
			p.setLong(1,accountNum2);
			ResultSet re = p.executeQuery();
			re.next();
			long prebal=re.getLong(1);
			deposit=prebal+amount;
			result=p.executeUpdate();
			 if(result>0)
		        {
		           
		            PreparedStatement stmt1=conn.prepareStatement("insert into transaction values(transaction1.nextval,?,?,?,?,?)");
		            stmt1.setLong(1, accountNum2);
		            stmt1.setLong(2, accountNum2);
		            stmt1.setLong(3, prebal);
		            stmt1.setLong(4, deposit);
		            stmt1.setString(5, "deposit");
		            int result1=stmt1.executeUpdate();
		           
		        }
			
			PreparedStatement stmt= conn.prepareStatement("update Account set balance=? where accNum=?");
			stmt.setLong(1,deposit);
			stmt.setLong(2,accountNum2);
			stmt.executeQuery();
		}catch (SQLException e){
			e.printStackTrace();
		}
			
			
	
			
			if(result>0)
				return deposit;
		        return 0;
	}

	@Override
	public long withdrawAmount(long accountNum3, int newBal1) {
		long withDraw = 0;
		int result = 0;
		Connection conn = DBconnect.getConnection();
		PreparedStatement p;
		try {
			p = conn.prepareStatement("select balance from Account where accNum=?");
			p.setLong(1, accountNum3);
			ResultSet re = p.executeQuery();
			re.next();
			long prebal = re.getLong(1);
			withDraw = prebal - newBal1;

			PreparedStatement stmt = conn.prepareStatement("update Account set balance=? where accNum=?");
			stmt.setLong(1, withDraw);
			stmt.setLong(2, accountNum3);
			result = p.executeUpdate();

			if (result > 0) {

				PreparedStatement stmt1 = conn
						.prepareStatement("insert into transaction values(transaction1.nextval,?,?,?,?,?)");
				stmt1.setLong(1, accountNum3);
				stmt1.setLong(2, accountNum3);
				stmt1.setLong(3, prebal);
				stmt1.setLong(4, withDraw);
				stmt1.setString(5, "withDraw");
				 stmt1.executeUpdate();

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		if (result > 0)
			return withDraw;
		    return 0;

	}

	@Override
	public long fundtransfer(long accountNum5, long accountNum6, int fundTrans) {
	
		Connection conn = DBconnect.getConnection();

		 

        PreparedStatement s1,s2,s3,s4;
        long balance=0;
        long newBal=0;
        long bal=0;
        long newBal1=0;
        try
        {
        s1 = conn.prepareStatement("select balance from Account where accNum=?");
        s1.setLong(1, accountNum5);
        ResultSet rs = s1.executeQuery();
        rs.next();
        balance = rs.getLong(1);
        newBal = balance - balance;
        
        s2 = conn.prepareStatement("update Account set balance=? where accNum=? ");
    
        s2.setLong(1, newBal);
        s2.setLong(2, accountNum5);
        int r=s2.executeUpdate();
        
        if(r>0)
        {
           
            PreparedStatement stmt1=conn.prepareStatement("insert into transaction values(transaction1.nextval,?,?,?,?,?)");
            stmt1.setLong(1, accountNum5);
            stmt1.setLong(2, accountNum6);
            stmt1.setLong(3, balance);
            stmt1.setLong(4, newBal);
            stmt1.setString(5, "fund transfer");
            int result1=stmt1.executeUpdate();
           
        }
        
        s3 = conn.prepareStatement("select balance from Account where accNum=?");
        s3.setLong(1, accountNum6);
        ResultSet rs1 = s1.executeQuery();
        rs1.next();
        bal = rs1.getLong(1);
        newBal1 = bal+ balance;
        
        s4 = conn.prepareStatement("update Account set balance=? where accNum=? ");
    
        s4.setLong(1, newBal1);
        s4.setLong(2, accountNum6);
        int r1=s4.executeUpdate();
        if(r>0)
        {
           
            PreparedStatement stmt1=conn.prepareStatement("insert into transaction values(transaction1.nextval,?,?,?,?,?)");
            stmt1.setLong(1, accountNum5);
            stmt1.setLong(2, accountNum6);
            stmt1.setLong(3, balance);
            stmt1.setLong(4, newBal);
            stmt1.setString(5, "fund transfer");
            int result1=stmt1.executeUpdate();
           
        }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        
        return balance;
		
		
	}

	@Override
	public void  getTranscation() {
		Connection conn = DBconnect.getConnection();
		Transcation bt=new Transcation();
		  try {
              PreparedStatement stmt=conn.prepareStatement("select * from transaction");
             ResultSet s= stmt.executeQuery();
             while(s.next())
             {
             long transId=s.getLong(1);
             int fromAcc=s.getInt(2);
             int toaccount=s.getInt(3);
             int oldBalance=s.getInt(4);
             int newBal=s.getInt(5);
             String type=s.getString(6);
             bt.setTid(transId);
             bt.setFromAccount(fromAcc);
             bt.setToaccount(toaccount);
             bt.setFromAccount(toaccount);
             bt.setNewBalance(newBal);
             bt. setTranscationType(type);
             System.out.println(bt);
        
             }
         }
        
         catch (Exception e) {
            
             e.printStackTrace();
         }
    
 
		
		
		
		
	}
}
