package com.cap.dao;

import java.util.List;

import com.cap.bean.Account;
import com.cap.bean.Transcation;
            // putting  the  datatypes and the variable names
public interface BankDao {
	long createAccount(Account acc);

	long showBalance(long accountNum2);

	long depositAmount(long accountNum2, int amount);

	long withdrawAmount(long accountNum3, int newBal1);

	long fundtransfer(long accountNum5, long accountNum6, int fundTrans);
	

	void getTranscation();
	 
	 
}
