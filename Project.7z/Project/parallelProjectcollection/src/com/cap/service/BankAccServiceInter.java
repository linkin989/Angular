package com.cap.service;

	 

	import java.util.List;

import com.cap.bean.BankAcc;
import com.cap.bean.BankAccTrans;

	 

	public interface BankAccServiceInter
	{
	    long createAcc(BankAcc Acc);
	    int showAccDetails(long BankAccNo);
	    long depositBankAcc(long BankAccNoDep, int amount);
	    long withDrawBankAcc(long BankAccNo1,int amt);
	    long fundTran(long AccNo1,long AccNo2,int fundTran);
	     List<BankAccTrans> printTrans();
	     boolean bkName(String bkName);
	     boolean mobNo(Long mobNo);
	}
