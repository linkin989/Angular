package com.cap.dao;

 

import java.util.List;

import com.cap.bean.BankAcc;
import com.cap.bean.BankAccTrans;

 

public interface BankAccDaoInter 
{
     long createAcc(BankAcc acc);
     int showAccDetails(Long BankAccNo);
     long depositBankAcc(long BankAccNoDep, int amount);
     long withDrawBankAcc(long BankAccNo1,int amt);
     long fundTran(long BankAccNo1, long BankAccNo2, int fundTran);
     List<BankAccTrans> printTrans();
}