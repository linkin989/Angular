package com.cap.dao;

import org.junit.Assert;

import org.junit.Test;

import com.cap.bean.BankAcc;

public class BankDaoTestImpl {
    //positive response
    BankAccDaoImpl dao=new BankAccDaoImpl();
    @Test
    public void createAcc_1()
    {
        BankAcc bank=new BankAcc();
        bank.setBkBal(1234);
        bank.setBkAcc(1001);
        bank.setBkAccType("savings");
        bank.setBkPhoneno(9898998988l);
        bank.setBkName("qwerty");
        long AccNum=dao.createAcc(bank);
        
        Assert.assertEquals(1001, AccNum);
        
    }
    //negative response
        @Test
        public void createAcc_2()
        {
            BankAcc bank=new BankAcc();
            bank.setBkBal(1234);
            bank.setBkAcc(1010);
            bank.setBkAccType("savings");
            bank.setBkPhoneno(9898998988l);
            bank.setBkName("qwerty");
            long AccNum=dao.createAcc(bank);
            
            Assert.assertEquals(1000,AccNum);
            
        }
}







