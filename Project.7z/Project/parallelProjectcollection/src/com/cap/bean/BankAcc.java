package com.cap.bean;

	public class BankAcc {
	    private long bkAcc;
	    private String bkName;
	    private String bkBran;
	    private String bkAccType;
	    private long bkPhoneno;
	    private int bkBal;

	 

	    public long getBkAcc() {
	        return bkAcc;
	    }
	    public void setBkAcc(long bkAcc) {
	        this.bkAcc = bkAcc;
	    }
	    public String getBkName() {
	        return bkName;
	    }
	    public void setBkName(String bkName) {
	        this.bkName = bkName;
	    }
	    public String getBkBran() {
	        return bkBran;
	    }
	    public void setBkBran(String bkBran) {
	        this.bkBran = bkBran;
	    }
	    public String getBkAccType() {
	        return bkAccType;
	    }
	    public void setBkAccType(String bkAccType) {
	        this.bkAccType = bkAccType;
	    }
	    public long getBkPhoneNo() {
	        return bkPhoneno;
	    }
	    public void setBkPhoneno(long bkPhoneno) {
	        this.bkPhoneno = bkPhoneno;
	    }
	    public int getBkBal() {
	        return bkBal;
	    }
	    public void setBkBal(int bkBal) {
	        this.bkBal = bkBal;
	    }
	    
	    @Override
	    public String toString() {
	        return " Account Holder Name=" + bkName + "\n Branch Name=" + bkBran + "\n Account Type=" + bkAccType
	                + "\n Phone Number=" + bkPhoneno + "\n Minimum Balance=" + bkBal ;
	    }
		 void setAccBalance(int i) {
			// TODO Auto-generated method stub
			
		}

	 

	}
