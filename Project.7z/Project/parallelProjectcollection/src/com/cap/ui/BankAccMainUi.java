package com.cap.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cap.bean.BankAcc;
import com.cap.bean.BankAccTrans;
import com.cap.exception.AccountNotFoundException;
import com.cap.service.BankAccServiceImpl;
import com.cap.service.BankAccServiceInter;

public class BankAccMainUi {
	static BankAccServiceInter service = new BankAccServiceImpl();

	static Scanner scanner = new Scanner(System.in);// user input

	public static void main(String[] args) {
		while (true) {
			System.out.println("1-Create A New Account");
			System.out.println("2-Show Balance");
			System.out.println("3-Deposit");
			System.out.println("4-Withdraw");
			System.out.println("5-Fund Transfer");
			System.out.println("6-Print Transactions");
			System.out.println("7-Exit");
			System.out.println("Enter your choice:");
			int choice = scanner.nextInt();
			// create account number and account details
			switch (choice) {
			case 1:
				String bkname;
				boolean isname;
				do {
					System.out.println("Enter your name");
					bkname = scanner.next();
					isname = service.bkName(bkname);
					if (!isname) {
						System.out.println("only alphabets are allowed in names");
					}

				} while (!isname);
				long mobNo;
				Boolean isnumber;
				do {
					System.out.println("enter your mobno");
					mobNo = scanner.nextLong();
					isnumber = service.mobNo(mobNo);
					if (!isnumber) {
						System.out.println("enter valid mobile number");
					}
				} while (!isnumber);
				try {
					@SuppressWarnings("resource")
					Scanner scanner = new Scanner(System.in);

					System.out.println("Enter the  Branch Name :");
					String bkBran = scanner.next();

					System.out.println("Enter the Account Type is:");
					String bkAccType = scanner.next();

					System.out.println("Enter the  Phone Number is:");
					long bkPhoneno = scanner.nextLong();

					System.out.println("Enter the Balance of the Account :");
					int bkBal = scanner.nextInt();

					long bkAcc = bkPhoneno - 14567389;
					System.out.println(" The Account Number is:" + bkAcc);

					BankAcc bk = new BankAcc();
					bk.setBkAcc(bkAcc);
					bk.setBkAccType(bkAccType);
					bk.setBkBran(bkBran);
					bk.setBkPhoneno(bkPhoneno);
					bk.setBkBal(bkBal);
					System.out.println("Branch Name=" + bkBran + "\n Account Type=" + bkAccType + "\n Phone Number="
							+ bkPhoneno + "\n Minimum Balance=" + bkBal);
					service.createAcc(bk);
				} catch (Exception e) {
					System.out.println("Please Enter the Valid Name, Account Branch, Account Type, Phone Number, Minimum Balance");
							
					System.out.println("Then Only Your Account Will be Created Succcessfully");
				}

				break;
			// showing the balance
			case 2:
				try {
					System.out.println("Enter the Account Number:");
					long BankAccNo = scanner.nextLong();
					int AccShow = service.showAccDetails(BankAccNo);

					System.out.println(AccShow);
				} catch (AccountNotFoundException e) {
					System.out.println(" Enter Valid Account Number");
				}
				break;
			// add the deposit amount
			case 3:
				try {
					System.out.println("Enter the Account Number:");
					long BankAccNoDeposit = scanner.nextLong();
					System.out.println("Enter the Deposit Amount:");
					int amount = scanner.nextInt();
					long AccDeposit = service.depositBankAcc(BankAccNoDeposit, amount);
					System.out.println(AccDeposit);
				} catch (Exception e) {
					System.out.println(
							"Please enter the Valid Account Number \n Or Please Enter the Valid Amount to Deposit");
				}
				break;
			// display the withdraw amount
			case 4:
				try {
					System.out.println("Enter the Account Number:");
					long BankAccWithDraw = scanner.nextLong();
					System.out.println("Enter the WithDraw Amount:");
					int amt = scanner.nextInt();
					long AccWithDraw = service.withDrawBankAcc(BankAccWithDraw, amt);
					System.out.println(AccWithDraw);
				} catch (Exception e) {
					System.out.println(
							"Please enter the Valid Account Number \n Or Please Enter the Valid Amount to WithDraw");
				}
				break;
			// fund transfer from one account to another account
			case 5:
				try {
					System.out.println("Enter the Sender Account Number:");
					long BankAccNo1 = scanner.nextLong();
					System.out.println("Enter the Receiver Account Number:");
					long BankAccNo2 = scanner.nextLong();
					System.out.println("Enter the Amount to send:");
					int fundTran = scanner.nextInt();
					long fundTrans = service.fundTran(BankAccNo1, BankAccNo2, fundTran);
					System.out.println(fundTrans);
				} catch (Exception e) {
					System.out.println(
							"Please enter the Valid Account Numbers \n Or Please Enter the Valid Amount to Fund Tranfer");
				}
				break;

			// showing the all transaction
			case 6:
				System.out.println("Showing all the Transaction");
				List<BankAccTrans> result = service.printTrans();
				Iterator<BankAccTrans> iterator = result.iterator();
				while (iterator.hasNext()) {
					BankAccTrans tran = iterator.next();
					System.out.println();
					System.out.println(tran);
				}
				break;

			case 7:
				System.out.println("Thank You ");
				System.exit(0);
				break;

			default:
				System.out.println("Wrong Choice \n Please enter the Valid Choice (1-7)");
			}

		}

	}

}
