package com.cap.service;



import com.cap.bean.Account;
import com.cap.dao.BankDao;
import com.cap.dao.BankDaoimpl;

public class BankServiceImpl implements BankService {
	BankDao dao = new BankDaoimpl();

	@Override
	public long createAccount(Account account) {
		dao.beginTransaction();
        long accNo=dao.createAccount(account);
        dao.commitTransaction();
		return accNo;
	}

	@Override
	public long showBalance(long accountNum2) {
		return  dao.showBalance(accountNum2);
	
	}

	
	@Override
	public long depositAmount(long accountNum2, int amount) {
		
		dao.beginTransaction();
		long updatedbal = dao.depositAmount(accountNum2, amount);
		dao.commitTransaction();
		return updatedbal;
	}

	@Override
	public long withdrawAmount(long accountNum3, int newBal1) {
		dao.beginTransaction();
		long updatedbal1 = dao.withdrawAmount(accountNum3, newBal1);
		dao.commitTransaction();
		return updatedbal1;
	}

	
	@Override
	public long fundTransfer(long accountNum5, long accountNum6, long fundTrans) {
		dao.beginTransaction();
		long updatedbal2 = dao.fundtransfer(accountNum5, accountNum6, fundTrans);
		dao.commitTransaction();
		return updatedbal2;

	}


	@Override
	public void getTranscation() {
		//dao.beginTransaction();
		dao.getTranscation();
		//dao.commitTransaction();
	}

	@Override
	public boolean nameValidation(String cusname) {
		if (cusname.matches("[A-Z][a-zA-Z]*"))
			return true;
		else
			return false;
	}

	@Override
	public boolean numberValid(long cusphone) {
		String num = Long.toString(cusphone);
		if (num.matches("[6-9][0-9]*"))
			return true;
		else
			return false;
	}

	@Override
	public boolean accTypevalid(String cusacctype) {
		if (cusacctype.equalsIgnoreCase("savings") || cusacctype.equalsIgnoreCase("current"))
			return true;
		else
			return false;

	}

	
	
	
	
	

	

	}

