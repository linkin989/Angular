package com.cap.dao;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.cap.bean.Account;

public class TestCase {

	
	  //positive response
    BankDaoimpl dao=new BankDaoimpl();
    @Test
    public void test1(){
        int deposit=500;
        long balance=dao.showBalance(1);
        long result=dao.depositAmount(1, deposit);
        long expectedResult=balance+500;
        assertEquals(expectedResult,result);
        System.out.println(expectedResult=result);
    }
//    //negative response
        @Test
        public void test2(){
            int deposit=500;
            long balance=dao.showBalance(1);
            long result=dao.depositAmount(1, deposit);
            long expectedResult=balance-500;
            assertEquals(expectedResult,result);
            System.out.println(expectedResult=result);
        }

}
