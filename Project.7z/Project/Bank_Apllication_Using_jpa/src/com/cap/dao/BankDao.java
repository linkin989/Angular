package com.cap.dao;



import com.cap.bean.Account;

            // putting  the  datatypes and the variable names
public interface BankDao {
	long createAccount(Account acc);

	long showBalance(long accountNum2);

	long depositAmount(long accountNum2, int amount);

	long withdrawAmount(long accountNum3, int newBal1);

	
	

	void getTranscation();

	void beginTransaction();

	void commitTransaction();

	long fundtransfer(long accountNum5, long accountNum6, long fundTrans);
	 
	 
}
