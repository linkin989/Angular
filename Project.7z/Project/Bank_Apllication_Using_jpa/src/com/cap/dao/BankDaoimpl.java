package com.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cap.bean.Account;
import com.cap.bean.Transaction;


public class BankDaoimpl implements BankDao {
	
	
	
   // EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA");
   
    private EntityManager entityManager;
    public BankDaoimpl() {
    	entityManager = JPAUtil.getEntityManager();
	}
	

	@Override
	public long createAccount(Account acc) {
		entityManager.persist(acc);
		return acc.getAccNum();
	}

	@Override
	public long showBalance(long accountNum2) {
		
		 Account account = entityManager.find(Account.class, accountNum2);
	        return account.getBalance();
	}

	@Override
	public long depositAmount(long accountNum2, int amount) {
		   Account account = entityManager.find(Account.class, accountNum2);
	        long oldbalance=account.getBalance();
	        long newBalance=oldbalance+amount;
	        entityManager.merge(account);
	        account.setBalance(newBalance);
	        
	        Transaction bt=new Transaction();
	        bt.setFromAccount(accountNum2);
	        bt.setToaccount(accountNum2);
	        bt.setOldBalance(oldbalance);
	        bt.setNewBalance(newBalance);
	        bt.setTranscationType("deposit");
	        entityManager.persist(bt);
	        
	        return newBalance;
	}

	@Override
	public long withdrawAmount(long accountNum3, int newBal1) {
		 Account account = entityManager.find(Account.class, accountNum3);
	        long oldbalance=account.getBalance();
	        long newBalance=oldbalance-newBal1;
	        entityManager.merge(account);
	        account.setBalance(newBalance);
	        Transaction bt=new Transaction();
	        bt.setFromAccount(accountNum3);
	        bt.setToaccount(accountNum3);
	        bt.setOldBalance(oldbalance);
	        bt.setNewBalance(newBalance);
	        bt.setTranscationType("withdraw");
	        entityManager.persist(bt);
	        return newBalance;
		
	}

	@Override
	public long fundtransfer(long accountNum5, long accountNum6, long fundTrans) {
		 Account account = entityManager.find(Account.class, accountNum5);
	        long oldbalance=account.getBalance();
	        long newBalance=oldbalance-fundTrans;
	        entityManager.merge(account);
	        account.setBalance(newBalance);
	        Transaction bt=new Transaction();
	        bt.setFromAccount(accountNum5);
	        bt.setToaccount(accountNum6);
	        bt.setOldBalance(oldbalance);
	        bt.setNewBalance(newBalance);
	        bt.setTranscationType("fdTransfer");
	        entityManager.persist(bt);
	        
	        
	        Account account1 = entityManager.find(Account.class, accountNum6);
	        long oldbalance1=account1.getBalance();
	        long newBalance1=oldbalance+fundTrans;
	        entityManager.merge(account1);
	        account1.setBalance(newBalance1);
	        Transaction b=new Transaction();
	        b.setFromAccount(accountNum5);
	        b.setToaccount(accountNum6);
	        b.setOldBalance(oldbalance);
	        b.setNewBalance(newBalance);
	        b.setTranscationType("credited");
	        entityManager.persist(b);
	        
	        return newBalance;
		
	}

	@Override
	public void getTranscation() {
		  TypedQuery<Transaction> q2=entityManager.createQuery("select c from Transaction c",Transaction.class);
          List<Transaction> l1=q2.getResultList();
          for(Transaction em1:l1)
          {
              System.out.println(em1.getTid()+"  "+em1.getFromAccount()+"  "+em1.getToaccount()+" "+em1.getOldBalance()+" "+em1.getNewBalance()+" "+em1.getTranscationType());
          }
             
  }
	

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		
	}


	}

