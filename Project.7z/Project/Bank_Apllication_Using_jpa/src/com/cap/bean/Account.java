package com.cap.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Account {
	
	@Id
	@GeneratedValue
	@Column(length=10)
	private long accNum;
	@Column(length=10)
	private String name;
	@Column(length=10)
	private long phoneNo;
	@Column(length=10)
	private long balance;
	@Column(length=10)
	private String accType;
	@Column(length=10)
	private String branch;

	public long getAccNum() {
		return accNum;
	}

	public void setAccNum(long cusnum) {
		this.accNum = cusnum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long newBalance) {
		this.balance = newBalance;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

  //creating string to string method
	public String toString() {
		return "Account [accNum=" + accNum + ", name=" + name + ", phoneNo=" + phoneNo + ", balance=" + balance
				+ ", accType=" + accType + ", branch=" + branch + "]";
	}

}
